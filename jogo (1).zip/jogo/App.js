import React, { useState, useEffect, useRef } from "react";
import {
  View, Text, TouchableOpacity, TextInput, StyleSheet, Animated, ScrollView, Modal, StatusBar
} from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';

const STATS_ZERADOS = { c1: 0, c2: 0, k1: 0, k2: 0 };
const SEM_CAT = "SEM CATEGORIA";

const IconeCinturao = ({ cor }) => (
  <View style={styles.cinturaoContainer}>
    <View style={[styles.cinturaoBase, { backgroundColor: cor === 'gold' ? '#F5C451' : '#E2E8F0' }]} />
    <View style={[styles.cinturaoCircle, { backgroundColor: cor === 'gold' ? '#B7791F' : '#94A3B8' }]} />
  </View>
);

const IconeMais = () => (
  <View style={styles.iconeMaisContainer}>
    <View style={styles.iconeMaisHorizontal} />
    <View style={styles.iconeMaisVertical} />
  </View>
);

const IconeEngrenagem = () => (
  <View style={styles.iconeEngrenagemContainer}>
    <View style={styles.iconeEngrenagemCentro} />
    <View style={[styles.iconeEngrenagemDente, { transform: [{ rotate: '0deg' }] }]} />
    <View style={[styles.iconeEngrenagemDente, { transform: [{ rotate: '45deg' }] }]} />
    <View style={[styles.iconeEngrenagemDente, { transform: [{ rotate: '90deg' }] }]} />
    <View style={[styles.iconeEngrenagemDente, { transform: [{ rotate: '135deg' }] }]} />
  </View>
);

const IconeLixeira = ({ cor = '#FFF' }) => (
  <View style={styles.iconeLixeiraContainer}>
    <View style={[styles.iconeLixeiraTampa, { backgroundColor: cor }]} />
    <View style={[styles.iconeLixeiraAlca, { borderColor: cor }]} />
    <View style={[styles.iconeLixeiraCorpo, { borderColor: cor }]}>
      <View style={[styles.iconeLixeiraLinha, { backgroundColor: cor }]} />
      <View style={[styles.iconeLixeiraLinha, { backgroundColor: cor }]} />
    </View>
  </View>
);

const LogoUfcCiems = () => (
  <View style={styles.logoContainerOuter}>
    <View style={styles.logoMolduraEsquerda} />
    <View style={styles.logoContainer}>
      <View style={styles.logoUfcQuadrado}>
        <Text style={styles.logoUfcTexto}>UFC</Text>
      </View>
      <View style={styles.logoDivisorVertical} />
      <View style={styles.logoCiemsContainer}>
        <Text style={styles.logoCiemsTexto}>CIEMS</Text>
        <Text style={styles.logoSubTexto}>CHAMPIONSHIP</Text>
      </View>
    </View>
    <View style={styles.logoMolduraDireita} />
  </View>
);

const ContadorStat = ({ rotulo, valor, onMais, onMenos, cor }) => (
  <View style={styles.statBox}>
    <Text style={styles.statRotulo}>{rotulo}</Text>
    <View style={styles.statLinha}>
      <TouchableOpacity style={styles.statBtn} onPress={onMenos} activeOpacity={0.6}>
        <Text style={styles.statBtnTxt}>−</Text>
      </TouchableOpacity>
      <Text style={[styles.statValor, { color: cor }]}>{valor}</Text>
      <TouchableOpacity style={[styles.statBtn, { borderColor: cor }]} onPress={onMais} activeOpacity={0.6}>
        <Text style={[styles.statBtnTxt, { color: cor }]}>+</Text>
      </TouchableOpacity>
    </View>
  </View>
);

const ItemLutadorDeslocavel = ({ nome, index, totalItens, onReorder, onEdit, onDelete }) => {
  return (
    <View style={[styles.rowGerenciarCard, styles.elementoLarguraPadrao]}>
      <View style={styles.containerControlesDeslocamento}>
        <TouchableOpacity
          disabled={index === 0}
          style={[styles.botaoSetaDeslocar, index === 0 && { opacity: 0.1 }]}
          onPress={() => onReorder(index, -1)}
        >
          <Text style={styles.textoSeta}>▲</Text>
        </TouchableOpacity>
        <TouchableOpacity
          disabled={index === totalItens - 1}
          style={[styles.botaoSetaDeslocar, index === totalItens - 1 && { opacity: 0.1 }]}
          onPress={() => onReorder(index, 1)}
        >
          <Text style={styles.textoSeta}>▼</Text>
        </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.botaoGerenciarNome} onPress={onEdit}>
        <Text style={styles.textoBotaoCardLutador}>{nome}</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botaoExcluirLutador} onPress={onDelete}>
        <IconeLixeira cor="#E11D2E" />
      </TouchableOpacity>
    </View>
  );
};

const textoStats = (st) => {
  if (!st) return "";
  const partes = [];
  if (st.c1 || st.c2) partes.push(`CRÍTICOS ${st.c1} x ${st.c2}`);
  if (st.k1 || st.k2) partes.push(`KNOCKDOWNS ${st.k1} x ${st.k2}`);
  return partes.join("  •  ");
};

export default function App() {
  const [tela, setTela] = useState("menu_inicial");
  const [menuVisivel, setMenuVisivel] = useState(false);
  const [modoTreino, setModoTreino] = useState(false);
  const [valeCinturao, setValeCinturao] = useState(null);
  const [modalAbandonar, setModalAbandonar] = useState(false);
  const [modalRetornarLuta, setModalRetornarLuta] = useState(false);
  const [roundAcabouAviso, setRoundAcabouAviso] = useState(false);
  const [modalAlerta, setModalAlerta] = useState({ visivel: false, titulo: "", mensagem: "", acaoOk: null });
  const [modalConfirmarGeral, setModalConfirmarGeral] = useState({ visivel: false, titulo: "", mensagem: "", acaoSim: null });
  const [modalFinalizacao, setModalFinalizacao] = useState({ visivel: false, metodo: null, alvo: null });
  const [modalExcluirConfirm, setModalExcluirConfirm] = useState(false);
  const [lutadorParaExcluir, setLutadorParaExcluir] = useState(null);
  const [modalOpcoesLixeira, setModalOpcoesLixeira] = useState(false);
  const [lutadorSelecionadoLixeira, setLutadorSelecionadoLixeira] = useState(null);
  const [modalRecuperarConfirm, setModalRecuperarConfirm] = useState(false);
  const [modalApagarDefinitivoConfirm, setModalApagarDefinitivoConfirm] = useState(false);
  const [historicoEventos, setHistoricoEventos] = useState([]);
  const [lutadoresDB, setLutadoresDB] = useState({
    CARANGUEJO: ["Isaac The Dablio", "Miguel Bolinha", "Gonçalves", "João Caralhão", "Charles William", "William Pretão", "Pedro Bellingham", "Arthur Jackson", "Bryan Brancão", "Kaleb Khabib"],
    TUBARÃO: ["Arthur China", "Thallysson W", "Luís Adolfo", "Benio The Black", "Gabriel Vertssapen", "Enzo Dela Vega", "Luan Ologna", "Miguel Jesus"],
    FEMININO: ["Nina Di Casteli", "Joana The Pig", "Mc Soares", "Antonella Di Marco", "Volkova", "Mary", "Charlotte"],
  });
  const [lixeiraDB, setLixeiraDB] = useState([]);
  const [lixeiraEventosDB, setLixeiraEventosDB] = useState([]);
  const [abaLixeira, setAbaLixeira] = useState("lutadores");
  const [eventoLixeiraSel, setEventoLixeiraSel] = useState(null);
  const [modalOpcoesLixeiraEvento, setModalOpcoesLixeiraEvento] = useState(false);
  const [novoLutadorNome, setNovoLutadorNome] = useState("");
  const [categoriaSelecionada, setCategoriaSelecionada] = useState(null);
  const [lutadorSendoEditado, setLutadorSendoEditado] = useState(null);
  const [categoriaAntigaEditado, setCategoriaAntigaEditado] = useState(null);
  const [novaCategoriaNome, setNovaCategoriaNome] = useState("");
  const [categoriaEditando, setCategoriaEditando] = useState(null);
  const [nomeCategoriaEdit, setNomeCategoriaEdit] = useState("");
  const [eventoEmAndamento, setEventoEmAndamento] = useState(null);
  const [inputEventoEspecial, setInputEventoEspecial] = useState("");
  const [idLutaAtiva, setIdLutaAtiva] = useState(null);
  const [lutaAtualIdx, setLutaAtualIdx] = useState(null);
  const [categoria, setCategoria] = useState(null);
  const [lutador1, setLutador1] = useState(null);
  const [lutador2, setLutador2] = useState(null);
  const [rounds, setRounds] = useState(null);
  const [roundAtual, setRoundAtual] = useState(1);
  const [vida1, setVida1] = useState(200);
  const [vida2, setVida2] = useState(200);
  const [turnos1, setTurnos1] = useState(0);
  const [turnos2, setTurnos2] = useState(0);
  const [vezDeQuem, setVezDeQuem] = useState(null);
  const [dano, setDano] = useState("");
  const [alvoSelecionado, setAlvoSelecionado] = useState(null);
  const [metodoSelecionado, setMetodoSelecionado] = useState(null);
  const [resultado, setResultado] = useState(null);
  const [itemSelecionado, setItemSelecionado] = useState(null);
  const [vencDecisaoTemp, setVencDecisaoTemp] = useState(null);
  const [pointsL1, setPointsL1] = useState("");
  const [pontosL2, setPontosL2] = useState("");
  const [stats, setStats] = useState(STATS_ZERADOS);
  const [pilhaTurnos, setPilhaTurnos] = useState([]);
  const [pilhaDano, setPilhaDano] = useState([]);
  // ===== PONTUAÇÃO POR ROUND =====
  const [roundScores, setRoundScores] = useState([]);
  const [ptsRound1, setPtsRound1] = useState(null);
  const [ptsRound2, setPtsRound2] = useState(null);
  const vidaMax = 200;
  const vidaAnim1 = useRef(new Animated.Value(vidaMax)).current;
  const vidaAnim2 = useRef(new Animated.Value(vidaMax)).current;
  const fadeTela = useRef(new Animated.Value(1)).current;
  const [carregado, setCarregado] = useState(false);

  useEffect(() => {
    fadeTela.setValue(0);
    Animated.timing(fadeTela, { toValue: 1, duration: 280, useNativeDriver: true }).start();
  }, [tela]);

  // ===== CATEGORIAS =====
  // Todas as categorias visíveis. "SEM CATEGORIA" só aparece se tiver ao menos 1 lutador.
  const listarCategorias = () => {
    const chaves = Object.keys(lutadoresDB || {});
    const reais = chaves.filter(c => c !== SEM_CAT);
    const temSemCat = (lutadoresDB[SEM_CAT] || []).length > 0;
    return temSemCat ? [...reais, SEM_CAT] : reais;
  };
  // Categorias "de verdade" (usadas para cadastrar/mover lutadores)
  const listarCategoriasReais = () => Object.keys(lutadoresDB || {}).filter(c => c !== SEM_CAT);

  const iniciarLuta = () => {
    setVida1(vidaMax);
    setVida2(vidaMax);
    setTurnos1(0);
    setTurnos2(0);
    setRoundAtual(1);
    setVezDeQuem(null);
    setAlvoSelecionado(null);
    setMetodoSelecionado(null);
    setRoundAcabouAviso(false);
    setStats(STATS_ZERADOS);
    setPilhaTurnos([]);
    setPilhaDano([]);
    setRoundScores([]);
    setPtsRound1(null);
    setPtsRound2(null);
    vidaAnim1.setValue(vidaMax);
    vidaAnim2.setValue(vidaMax);
    setTela("escolher_rounds");
  };

  const ordenarLutasDoEvento = (lutas, nomeEvento) => {
    if (!lutas || !Array.isArray(lutas)) return [];
    const nomeNormalizado = nomeEvento ? String(nomeEvento).toUpperCase().trim() : "";
    return [...lutas].sort((a, b) => {
      if (nomeNormalizado === "UFC MUNICH") {
        const pesoA = a.cinturao && a.corCinturao === 'silver' ? 2 : (a.cinturao && a.corCinturao === 'gold' ? 1 : 0);
        const pesoB = b.cinturao && b.corCinturao === 'silver' ? 2 : (b.cinturao && b.corCinturao === 'gold' ? 1 : 0);
        return pesoB - pesoA;
      } else {
        const pesoA = a.cinturao && a.corCinturao === 'gold' ? 2 : (a.cinturao && a.corCinturao === 'silver' ? 1 : 0);
        const pesoB = b.cinturao && b.corCinturao === 'gold' ? 2 : (b.cinturao && b.corCinturao === 'silver' ? 1 : 0);
        return pesoB - pesoA;
      }
    });
  };

  const mostrarAlertaCustom = (titulo, mensagem, acao = null) => {
    setModalAlerta({ visivel: true, titulo, mensagem: mensagem, acaoOk: acao });
  };

  const getLabelLutaPorArrayOriginal = (lutadorA, lutadorB) => {
    if (modoTreino) return "TREINO";
    if (!eventoEmAndamento || !eventoEmAndamento.lutasAgendadas) return "PRELIMINARY CARD";
    const idxOriginal = eventoEmAndamento.lutasAgendadas.findIndex(
      l => l.lutador1 === lutadorA && l.lutador2 === lutadorB
    );
    if (idxOriginal === 0) return "MAIN EVENT";
    if (idxOriginal === 1) return "CO-MAIN EVENT";
    return "PRELIMINARY CARD";
  };

  const getContagemLutas = (p1, p2) => {
    let contador = 1;
    historicoEventos.forEach(ev => {
      if(ev && ev.lutasAgendadas) {
        ev.lutasAgendadas.forEach(l => {
          if ((l.lutador1 === p1 && l.lutador2 === p2) || (l.lutador1 === p2 && l.lutador2 === p1)) {
            contador++;
          }
        });
      }
    });
    if (eventoEmAndamento && eventoEmAndamento.lutasAgendadas) {
      eventoEmAndamento.lutasAgendadas.forEach(l => {
        if ((l.lutador1 === p1 && l.lutador2 === p2) || (l.lutador1 === p2 && l.lutador2 === p1)) {
          contador++;
        }
      });
    }
    return contador > 1 ? contador : "";
  };

  const getProximoNumerado = () => {
    const numerados = historicoEventos.filter(ev => ev && ev.nome && /^UFC \d+$/.test(ev.nome));
    if (numerados.length === 0) return 324;
    const nums = numerados.map(ev => parseInt(ev.nome.replace("UFC ", "")) || 0);
    return Math.max(...nums) + 1;
  };

  const getCartel = (nome) => {
    let v = 0, d = 0, e = 0;
    const todasLutas = historicoEventos.reduce((acc, ev) => acc.concat(ev.lutasAgendadas || []), []);
    todasLutas.forEach(l => {
      if (!l || !l.resultado) return;
      if (l.lutador1 === nome || l.lutador2 === nome) {
        if (l.resultado.metodo === "EMPATE") e++;
        else if (l.resultado.vencedor === nome) v++;
        else d++;
      }
    });
    return `${v}-${d}-${e}`;
  };

  // Turno atual do round (1 a 10): avança quando os dois lutadores já completaram o turno anterior
  const getTurnoAtual = () => Math.min(10, Math.min(turnos1, turnos2) + 1);

  useEffect(() => {
    if (tela !== "luta") return;
    Animated.timing(vidaAnim1, {
      toValue: vida1,
      duration: 600,
      useNativeDriver: false
    }).start();
    if (vida1 <= 0) { finalizarLuta("TKO", lutador2, getTurnoAtual(), roundAtual); }
  }, [vida1, tela]);

  useEffect(() => {
    if (tela !== "luta") return;
    Animated.timing(vidaAnim2, {
      toValue: vida2,
      duration: 600,
      useNativeDriver: false
    }).start();
    if (vida2 <= 0) { finalizarLuta("TKO", lutador1, getTurnoAtual(), roundAtual); }
  }, [vida2, tela]);

  useEffect(() => {
    const salvarDados = async () => {
      if (carregado) {
        try {
          const dados = JSON.stringify({ historicoEventos, eventoEmAndamento, lutadoresDB, lixeiraDB, lixeiraEventosDB });
          await AsyncStorage.setItem('ufc_dados', dados);
        } catch (e) {
          console.log("Erro ao salvar no AsyncStorage:", e);
        }
      }
    };
    salvarDados();
  }, [historicoEventos, eventoEmAndamento, lutadoresDB, lixeiraDB, lixeiraEventosDB, carregado]);

  useEffect(() => {
    const carregarDados = async () => {
      try {
        const dadosSalvos = await AsyncStorage.getItem('ufc_dados');
        if (dadosSalvos) {
          const dados = JSON.parse(dadosSalvos);
          if (dados.historicoEventos) setHistoricoEventos(dados.historicoEventos);
          if (dados.eventoEmAndamento) setEventoEmAndamento(dados.eventoEmAndamento);
          if (dados.lutadoresDB) setLutadoresDB(dados.lutadoresDB);
          if (dados.lixeiraDB) setLixeiraDB(dados.lixeiraDB);
          if (dados.lixeiraEventosDB) setLixeiraEventosDB(dados.lixeiraEventosDB);
        }
      } catch (e) {
        console.log("Erro ao carregar dados do AsyncStorage:", e);
      } finally {
        setCarregado(true);
      }
    };
    carregarDados();
  }, []);

  const handleAdicionarLutador = () => {
    if(!novoLutadorNome.trim() || !categoriaSelecionada){
      mostrarAlertaCustom("ERRO", "PREENCHA O NOME E SELECIONE UMA CATEGORIA!");
      return;
    }
    const nomeNormalizado = novoLutadorNome.trim();
    const existeAtivo = Object.values(lutadoresDB).some(catList => (catList || []).includes(nomeNormalizado));
    if (existeAtivo) {
      mostrarAlertaCustom("ERRO", "JÁ EXISTE UM LUTADOR ATIVO COM ESSE NOME!");
      return;
    }
    setLutadoresDB(prev => ({
      ...prev,
      [categoriaSelecionada]: [...(prev[categoriaSelecionada] || []), nomeNormalizado]
    }));
    mostrarAlertaCustom("SUCESSO", `${nomeNormalizado.toUpperCase()} ADICIONADO!`, () => {
      setNovoLutadorNome(""); setCategoriaSelecionada(null); setTela("menu_inicial");
    });
  };

  const handleSalvarEdicaoLutador = () => {
    if(!novoLutadorNome.trim() || !categoriaSelecionada){
      mostrarAlertaCustom("ERRO", "O NOME E A CATEGORIA NÃO PODEM FICAR VAZIOS!");
      return;
    }
    const nomeNovo = novoLutadorNome.trim();
    setLutadoresDB(prev => {
      const copiaCategoriaAntiga = (prev[categoriaAntigaEditado] || []).filter(l => l !== lutadorSendoEditado);
      let novoEstado = { ...prev, [categoriaAntigaEditado]: copiaCategoriaAntiga };
      novoEstado[categoriaSelecionada] = [...(novoEstado[categoriaSelecionada] || []), nomeNovo];
      return novoEstado;
    });
    mostrarAlertaCustom("SUCESSO", "LUTADOR ATUALIZADO!", () => {
      setNovoLutadorNome(""); setLutadorSendoEditado(null); setCategoriaSelecionada(null); setCategoriaAntigaEditado(null);
      setCategoria(null);
      setTela("gerenciar_lutadores");
    });
  };

  const handleReordenarLutadores = (indexAntigo, direcao) => {
    if(!lutadoresDB[categoria]) return;
    const listaAtual = [...lutadoresDB[categoria]];
    let novoIndex = indexAntigo + direcao;
    if (novoIndex < 0 || novoIndex >= listaAtual.length) return;
    const temp = listaAtual[indexAntigo];
    listaAtual[indexAntigo] = listaAtual[novoIndex];
    listaAtual[novoIndex] = temp;
    setLutadoresDB(prev => ({
      ...prev,
      [categoria]: listaAtual
    }));
  };

  // ===== GERENCIAR CATEGORIAS =====
  const handleAdicionarCategoria = () => {
    const nome = novaCategoriaNome.trim().toUpperCase();
    if (!nome) {
      mostrarAlertaCustom("ERRO", "DIGITE O NOME DA CATEGORIA!");
      return;
    }
    if (nome === SEM_CAT) {
      mostrarAlertaCustom("ERRO", "ESSE NOME É RESERVADO PELO SISTEMA!");
      return;
    }
    if (Object.keys(lutadoresDB).includes(nome)) {
      mostrarAlertaCustom("ERRO", "JÁ EXISTE UMA CATEGORIA COM ESSE NOME!");
      return;
    }
    setLutadoresDB(prev => ({ ...prev, [nome]: [] }));
    setNovaCategoriaNome("");
    mostrarAlertaCustom("SUCESSO", `CATEGORIA ${nome} CRIADA!`);
  };

  const handleSalvarCategoria = () => {
    const nomeNovo = nomeCategoriaEdit.trim().toUpperCase();
    if (!nomeNovo) {
      mostrarAlertaCustom("ERRO", "O NOME DA CATEGORIA NÃO PODE FICAR VAZIO!");
      return;
    }
    if (nomeNovo === SEM_CAT) {
      mostrarAlertaCustom("ERRO", "ESSE NOME É RESERVADO PELO SISTEMA!");
      return;
    }
    if (nomeNovo !== categoriaEditando && Object.keys(lutadoresDB).includes(nomeNovo)) {
      mostrarAlertaCustom("ERRO", "JÁ EXISTE UMA CATEGORIA COM ESSE NOME!");
      return;
    }
    const antigo = categoriaEditando;
    if (nomeNovo !== antigo) {
      setLutadoresDB(prev => {
        const novo = {};
        Object.keys(prev).forEach(k => { novo[k === antigo ? nomeNovo : k] = prev[k]; });
        return novo;
      });
      setLixeiraDB(prev => prev.map(l => l.categoria === antigo ? { ...l, categoria: nomeNovo } : l));
    }
    setCategoriaEditando(null);
    setNomeCategoriaEdit("");
    mostrarAlertaCustom("SUCESSO", "CATEGORIA ATUALIZADA!");
  };

  const excluirCategoria = (cat) => {
    setLutadoresDB(prev => {
      const lista = prev[cat] || [];
      const novo = { ...prev };
      delete novo[cat];
      if (lista.length > 0) {
        novo[SEM_CAT] = [...(novo[SEM_CAT] || []), ...lista];
      }
      return novo;
    });
    setLixeiraDB(prev => prev.map(l => l.categoria === cat ? { ...l, categoria: SEM_CAT } : l));
    mostrarAlertaCustom("AVISO", "CATEGORIA EXCLUÍDA. OS LUTADORES FORAM MOVIDOS PARA 'SEM CATEGORIA'.");
  };

  // ===== LIXEIRA DE LUTADORES =====
  const acionarExclusaoLutador = (nome, catOrigem) => {
    setLutadorParaExcluir({ nome, categoria: catOrigem });
    setModalExcluirConfirm(true);
  };

  const confirmarMoverParaLixeira = () => {
    if (!lutadorParaExcluir) return;
    setLutadoresDB(prev => ({
      ...prev,
      [lutadorParaExcluir.categoria]: (prev[lutadorParaExcluir.categoria] || []).filter(l => l !== lutadorParaExcluir.nome)
    }));
    setLixeiraDB(prev => [...prev, { nome: lutadorParaExcluir.nome, categoria: lutadorParaExcluir.categoria }]);
    setModalExcluirConfirm(false);
    setLutadorParaExcluir(null);
    mostrarAlertaCustom("AVISO", "LUTADOR MOVIDO PARA A LIXEIRA.");
  };

  const confirmarRecuperacao = () => {
    if (!lutadorSelecionadoLixeira) return;
    const { nome, categoria: catOriginal } = lutadorSelecionadoLixeira;
    const jaExiste = Object.values(lutadoresDB).some(lista => (lista || []).includes(nome));
    if (jaExiste) {
      setModalRecuperarConfirm(false);
      mostrarAlertaCustom("ERRO", "JÁ EXISTE UM LUTADOR ATIVO COM ESSE NOME!");
      return;
    }
    // Se a categoria original foi excluída, o lutador volta como "Sem Categoria"
    const categoriaExiste = Object.keys(lutadoresDB).includes(catOriginal);
    const destino = categoriaExiste ? catOriginal : SEM_CAT;
    setLutadoresDB(prev => ({
      ...prev,
      [destino]: [...(prev[destino] || []), nome]
    }));
    setLixeiraDB(prev => prev.filter(l => l.nome !== nome));
    setModalRecuperarConfirm(false);
    setLutadorSelecionadoLixeira(null);
    setModalOpcoesLixeira(false);
    mostrarAlertaCustom("SUCESSO", destino === SEM_CAT && catOriginal !== SEM_CAT ? "LUTADOR RECUPERADO EM 'SEM CATEGORIA' (A CATEGORIA ORIGINAL NÃO EXISTE MAIS)." : "LUTADOR RECUPERADO COM SUCESSO!");
  };

  const confirmarApagarDefinitivo = () => {
    if (!lutadorSelecionadoLixeira) return;
    setLixeiraDB(prev => prev.filter(l => l.nome !== lutadorSelecionadoLixeira.nome));
    setModalApagarDefinitivoConfirm(false);
    setLutadorSelecionadoLixeira(null);
    setModalOpcoesLixeira(false);
    mostrarAlertaCustom("SUCESSO", "LUTADOR EXCLUÍDO PERMANENTEMENTE.");
  };

  // ===== LIXEIRA DE EVENTOS =====
  const moverEventoParaLixeira = (evento, origem) => {
    setLixeiraEventosDB(prev => [{ ...evento, origemLixeira: origem, excluidoEm: Date.now() }, ...prev]);
  };

  const excluirEventoHistorico = (ev, idx) => {
    moverEventoParaLixeira(ev, "historico");
    setHistoricoEventos(prev => prev.filter((_, i) => i !== idx));
  };

  const excluirEventoAtual = () => {
    if (eventoEmAndamento) moverEventoParaLixeira(eventoEmAndamento, "andamento");
    setEventoEmAndamento(null);
    setTela("menu_inicial");
  };

  const recuperarEventoDaLixeira = () => {
    const ev = eventoLixeiraSel;
    if (!ev) return;
    const { origemLixeira, excluidoEm, ...evento } = ev;
    if (origemLixeira === "andamento") {
      if (eventoEmAndamento) {
        mostrarAlertaCustom("AVISO", "JÁ EXISTE UM EVENTO EM ANDAMENTO. ENCERRE OU EXCLUA ELE ANTES DE RECUPERAR ESTE.");
        return;
      }
      setEventoEmAndamento(evento);
    } else {
      setHistoricoEventos(prev => [evento, ...prev]);
    }
    setLixeiraEventosDB(prev => prev.filter(e => e.excluidoEm !== excluidoEm));
    setEventoLixeiraSel(null);
    mostrarAlertaCustom("SUCESSO", "EVENTO RECUPERADO COM SUCESSO!");
  };

  const apagarEventoDefinitivo = () => {
    const ev = eventoLixeiraSel;
    if (!ev) return;
    setLixeiraEventosDB(prev => prev.filter(e => e.excluidoEm !== ev.excluidoEm));
    setEventoLixeiraSel(null);
    mostrarAlertaCustom("SUCESSO", "EVENTO EXCLUÍDO PERMANENTEMENTE.");
  };

  const registrarTurno = (num) => {
    setAlvoSelecionado(null);
    let novosT1 = turnos1;
    let novosT2 = turnos2;
    let incrementou = false;
    if (num === 1) {
      if (turnos1 < 10) { novosT1 = turnos1 + 1; incrementou = true; }
      setTurnos1(novosT1); setVezDeQuem(2);
    } else {
      if (turnos2 < 10) { novosT2 = turnos2 + 1; incrementou = true; }
      setTurnos2(novosT2); setVezDeQuem(1);
    }
    if (incrementou) setPilhaTurnos(p => [...p, num]);
    if (novosT1 + novosT2 >= 20) {
      setRoundAcabouAviso(true);
    }
  };

  const desfazerTurno = () => {
    if (pilhaTurnos.length === 0) return;
    const num = pilhaTurnos[pilhaTurnos.length - 1];
    const restante = pilhaTurnos.slice(0, -1);
    setPilhaTurnos(restante);
    if (num === 1) setTurnos1(t => Math.max(0, t - 1));
    else setTurnos2(t => Math.max(0, t - 1));
    setVezDeQuem(restante.length === 0 ? null : num);
    setRoundAcabouAviso(false);
    setAlvoSelecionado(null);
  };

  const aplicarDano = (alvo, valor) => {
    const atual = alvo === 1 ? vida1 : vida2;
    const efetivo = Math.min(valor, atual);
    if (efetivo <= 0) return;
    setPilhaDano(p => [...p, { alvo, valor: efetivo }]);
    if (alvo === 1) setVida1(p => Math.max(0, p - valor));
    else setVida2(p => Math.max(0, p - valor));
  };

  const desfazerDano = () => {
    if (pilhaDano.length === 0) return;
    const ultimo = pilhaDano[pilhaDano.length - 1];
    setPilhaDano(pilhaDano.slice(0, -1));
    if (ultimo.alvo === 1) setVida1(p => Math.min(vidaMax, p + ultimo.valor));
    else setVida2(p => Math.min(vidaMax, p + ultimo.valor));
  };

  const ajustarStat = (chave, delta) => {
    setStats(s => ({ ...s, [chave]: Math.max(0, (s[chave] || 0) + delta) }));
  };

  const processarProximoRound = () => {
    setRoundAcabouAviso(false);
    if (roundAtual < rounds) {
      setRoundAtual(r => r + 1);
      setTurnos1(0);
      setTurnos2(0);
      setVezDeQuem(null);
      setPilhaTurnos([]);
    } else {
      setTela("escolher_vencedor_decisao");
    }
  };

  // ===== PONTUAÇÃO DO ROUND =====
  // Máximo 10 para cada; se um tiver 10, o outro tem no máximo 9.
  const escolherPontoRound = (lado, v) => {
    const outro = lado === 1 ? ptsRound2 : ptsRound1;
    if (v === 10 && outro === 10) return;
    if (lado === 1) setPtsRound1(ptsRound1 === v ? null : v);
    else setPtsRound2(ptsRound2 === v ? null : v);
  };

  const confirmarPontuacaoRound = () => {
    if (ptsRound1 === null || ptsRound2 === null) {
      mostrarAlertaCustom("ERRO", "MARQUE A PONTUAÇÃO DOS DOIS LUTADORES!");
      return;
    }
    if (ptsRound1 === 10 && ptsRound2 === 10) {
      mostrarAlertaCustom("ERRO", "SE UM LUTADOR TEM 10, O OUTRO TEM NO MÁXIMO 9!");
      return;
    }
    const novos = [...roundScores, { round: roundAtual, p1: ptsRound1, p2: ptsRound2 }];
    setRoundScores(novos);
    setPtsRound1(null);
    setPtsRound2(null);
    if (roundAtual < rounds) {
      processarProximoRound();
      setTela("luta");
    } else {
      // Último round: já preenche o total da decisão (pode ser editado depois)
      setPointsL1(String(novos.reduce((s, r) => s + r.p1, 0)));
      setPontosL2(String(novos.reduce((s, r) => s + r.p2, 0)));
      processarProximoRound(); // vai para a escolha do vencedor
    }
  };

  const handleConfirmarAbandono = () => {
    setModalAbandonar(false);
    if (!modoTreino && eventoEmAndamento) {
      const novasLutas = eventoEmAndamento.lutasAgendadas.map(l => {
        if (l.idLuta === idLutaAtiva) {
          return {
            ...l,
            status: "Interrompida",
            dadosSalvos: { vida1, vida2, turnos1, turnos2, roundAtual, rounds, vezDeQuem, stats, pilhaTurnos, pilhaDano, roundScores }
          };
        }
        return l;
      });
      setEventoEmAndamento({ ...eventoEmAndamento, lutasAgendadas: novasLutas });
    }
    resetarEstadosDeCombate();
    setTela(modoTreino ? "menu_inicial" : "continuar_evento");
  };

  const resetarEstadosDeCombate = () => {
    setVida1(200); setVida2(200); setTurnos1(0); setTurnos2(0); setRoundAtual(1);
    setMetodoSelecionado(null); setAlvoSelecionado(null); setVezDeQuem(null); setDano("");
    setPointsL1(""); setPontosL2(""); setVencDecisaoTemp(null); setRoundAcabouAviso(false);
    setStats(STATS_ZERADOS); setPilhaTurnos([]); setPilhaDano([]);
    setRoundScores([]); setPtsRound1(null); setPtsRound2(null);
    setIdLutaAtiva(null);
  };

  const finalizarLuta = (metodo, vencedor, turnoVenc, roundVenc, pontosDec = null) => {
    const res = {
      vencedor, metodo, round: roundVenc, turno: turnoVenc,
      lutador1, lutador2, tipoEventoLuta: getLabelLutaPorArrayOriginal(lutador1, lutador2),
      nomeDoEvento: modoTreino ? "TREINO" : eventoEmAndamento?.nome || "EVENTO",
      pointsDec: pontosDec, stats: { ...stats }, roundScores: [...roundScores]
    };
    if (!modoTreino && eventoEmAndamento) {
      const novasLutas = eventoEmAndamento.lutasAgendadas.map(l => {
        if (l.idLuta === idLutaAtiva) {
          return { ...l, status: "Finalizada", resultado: res, dadosSalvos: null };
        }
        return l;
      });
      const novoEvento = { ...eventoEmAndamento, lutasAgendadas: novasLutas };
      setEventoEmAndamento(novoEvento);
      if (novasLutas.every(l => l.status === "Finalizada")) {
        setHistoricoEventos(prev => [novoEvento, ...prev]);
      }
    }
    setResultado(res);
    setTela("resultado");
  };

  const concluirLutaEResetar = () => {
    resetarEstadosDeCombate();
    if (modoTreino) {
      setModoTreino(false); setLutador1(null); setLutador2(null); setTela("menu_inicial");
    } else {
      if (eventoEmAndamento && eventoEmAndamento.lutasAgendadas.every(l => l.status === "Finalizada")) {
        setEventoEmAndamento(null); setTela("menu_inicial");
      } else {
        setTela("continuar_evento");
      }
    }
  };

  const handleEncerrarEventoManual = () => {
    if (!eventoEmAndamento) return;
    const lutasCompletas = eventoEmAndamento.lutasAgendadas.filter(l => l.status === "Finalizada");
    if (lutasCompletas.length > 0) {
      const eventoFiltradoParaHistorico = {
        ...eventoEmAndamento,
        lutasAgendadas: lutasCompletas
      };
      setHistoricoEventos(prev => [eventoFiltradoParaHistorico, ...prev]);
    }
    setEventoEmAndamento(null);
    resetarEstadosDeCombate();
    setTela("menu_inicial");
    mostrarAlertaCustom("EVENTO FINALIZADO", "O evento foi encerrado. Lutas completas foram salvas e as incompletas foram apagadas.");
  };

  const renderTelaConteudo = () => {
    if (tela === "menu_inicial") return (
      <View style={styles.containerCentro}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setMenuVisivel(true)} style={styles.hitboxMenu}>
            <Text style={styles.tresPontos}>⋮</Text>
          </TouchableOpacity>
        </View>
        <LogoUfcCiems />
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao]} onPress={() => { setModoTreino(false); setLutador1(null); setLutador2(null); setCategoria(null); setTela("selecao_tipo_evento"); }}>
          <Text style={styles.textoBotaoMain}>CRIAR NOVO EVENTO</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoSecundarioBorda, styles.elementoLarguraPadrao, {marginTop: 14}]} onPress={() => { setModoTreino(true); setLutaAtualIdx(0); setLutador1(null); setLutador2(null); setCategoria(null); setTela("agendar_lutas"); }}>
          <Text style={styles.textoBotaoSecundario}>LUTA RÁPIDA (TREINO)</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoSecundarioBorda, styles.elementoLarguraPadrao, {marginTop: 14}, eventoEmAndamento && styles.botaoMainAtivoAzul]} onPress={() => eventoEmAndamento ? setTela("continuar_evento") : setModalAlerta({ visivel: true, titulo: "AVISO", mensagem: "NÃO HÁ EVENTO EM ANDAMENTO!" })}>
          <Text style={[styles.textoBotaoSecundario, eventoEmAndamento && {color: '#FFF'}]}>CONTINUAR EVENTO</Text>
        </TouchableOpacity>
        <View style={[styles.divisorLine, styles.elementoLarguraPadrao]} />
        <TouchableOpacity style={[styles.botaoSecundarioBorda, styles.elementoLarguraPadrao, {borderColor: '#2A2A35'}]} onPress={() => { setNovoLutadorNome(""); setCategoriaSelecionada(null); setTela("adicionar_lutador"); }}>
          <View style={styles.rowBotaoComIcone}>
            <IconeMais />
            <Text style={styles.textoBotaoSecundarioBranco}>ADICIONAR LUTADOR</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoSecundarioBorda, styles.elementoLarguraPadrao, {marginTop: 14, borderColor: '#2A2A35'}]} onPress={() => { setCategoria(null); setLutadorSendoEditado(null); setTela("gerenciar_informacoes"); }}>
          <View style={styles.rowBotaoComIcone}>
            <IconeEngrenagem />
            <Text style={styles.textoBotaoSecundarioBranco}>GERENCIAR INFORMAÇÕES</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
    if (tela === "gerenciar_informacoes") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>GERENCIAR INFORMAÇÕES</Text>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setCategoria(null); setLutadorSendoEditado(null); setTela("gerenciar_lutadores"); }}>
          <Text style={styles.textoBotaoCardLista}>GERENCIAR LUTADORES</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setCategoriaEditando(null); setNovaCategoriaNome(""); setTela("gerenciar_categorias"); }}>
          <Text style={styles.textoBotaoCardLista}>GERENCIAR CATEGORIAS</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "gerenciar_categorias") return (
      <View style={styles.container}>
        <Text style={styles.titulo}>GERENCIAR CATEGORIAS</Text>
        <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
          {!categoriaEditando ? (
            <>
              <Text style={styles.nomeLabel}>NOVA CATEGORIA:</Text>
              <TextInput style={[styles.inputPremium, styles.elementoLarguraPadrao]} placeholder="NOME DA CATEGORIA" placeholderTextColor="#55555F" value={novaCategoriaNome} onChangeText={setNovaCategoriaNome} />
              <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao]} onPress={handleAdicionarCategoria}>
                <Text style={styles.textoBotaoMain}>ADICIONAR CATEGORIA</Text>
              </TouchableOpacity>
              <View style={[styles.divisorLine, styles.elementoLarguraPadrao]} />
              <Text style={styles.subtituloInformativo}>TOQUE NO NOME PARA RENOMEAR OU NA LIXEIRA PARA EXCLUIR:</Text>
              {listarCategoriasReais().length === 0 && (
                <Text style={styles.textoListaVazia}>NENHUMA CATEGORIA CADASTRADA.</Text>
              )}
              {listarCategoriasReais().map(cat => (
                <View key={cat} style={[styles.rowGerenciarCard, styles.elementoLarguraPadrao]}>
                  <TouchableOpacity style={styles.botaoGerenciarNome} onPress={() => { setCategoriaEditando(cat); setNomeCategoriaEdit(cat); }}>
                    <Text style={styles.textoBotaoCardLutador}>{cat} <Text style={{color: '#8A8A98', fontSize: 12}}>({(lutadoresDB[cat] || []).length})</Text></Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.botaoExcluirLutador}
                    onPress={() => setModalConfirmarGeral({
                      visivel: true,
                      titulo: "EXCLUIR CATEGORIA",
                      mensagem: (lutadoresDB[cat] || []).length > 0
                        ? `A CATEGORIA ${cat} SERÁ EXCLUÍDA. OS ${(lutadoresDB[cat] || []).length} LUTADOR(ES) CONTINUARÃO EXISTINDO NA CATEGORIA "SEM CATEGORIA". CONFIRMA?`
                        : `DESEJA EXCLUIR A CATEGORIA ${cat}?`,
                      acaoSim: () => excluirCategoria(cat)
                    })}
                  >
                    <IconeLixeira cor="#E11D2E" />
                  </TouchableOpacity>
                </View>
              ))}
              {(lutadoresDB[SEM_CAT] || []).length > 0 && (
                <Text style={[styles.subtituloInformativo, {marginTop: 16}]}>EXISTEM {(lutadoresDB[SEM_CAT] || []).length} LUTADOR(ES) EM "SEM CATEGORIA". MOVA-OS EM GERENCIAR LUTADORES.</Text>
              )}
            </>
          ) : (
            <View style={[styles.cardFormularioEdicao, styles.elementoLarguraPadrao]}>
              <Text style={[styles.titulo, {fontSize: 18, color: '#E11D2E'}]}>EDITANDO: {categoriaEditando}</Text>
              <Text style={styles.nomeLabel}>NOME DA CATEGORIA:</Text>
              <TextInput style={styles.inputPremium} placeholder="NOME DA CATEGORIA" placeholderTextColor="#55555F" value={nomeCategoriaEdit} onChangeText={setNomeCategoriaEdit} />
              <TouchableOpacity style={styles.botaoMainNeon} onPress={handleSalvarCategoria}>
                <Text style={styles.textoBotaoMain}>SALVAR ALTERAÇÕES</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.botaoVoltarCinzaBorda} onPress={() => { setCategoriaEditando(null); setNomeCategoriaEdit(""); }}>
                <Text style={styles.textoBotaoVoltarBorda}>CANCELAR EDIÇÃO</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
        {!categoriaEditando && (
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("gerenciar_informacoes")}>
            <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
          </TouchableOpacity>
        )}
      </View>
    );
    if (tela === "adicionar_lutador") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>NOVO LUTADOR</Text>
        <TextInput style={[styles.inputPremium, styles.elementoLarguraPadrao]} placeholder="NOME DO LUTADOR" placeholderTextColor="#55555F" value={novoLutadorNome} onChangeText={setNovoLutadorNome} />
        <Text style={[styles.nomeLabel, {textAlign: 'center', marginVertical: 15}]}>SELECIONE A CATEGORIA:</Text>
        <View style={[styles.rowCategoriasTabs, styles.elementoLarguraPadrao]}>
          {listarCategoriasReais().map(cat => (
            <TouchableOpacity key={cat} style={[styles.tabCategoriaBotao, categoriaSelecionada === cat && styles.tabCategoriaAtiva]} onPress={() => setCategoriaSelecionada(cat)}>
              <Text style={styles.textoBotaoAlvo}>{cat}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {listarCategoriasReais().length === 0 && (
          <Text style={styles.subtituloInformativo}>CRIE UMA CATEGORIA EM GERENCIAR INFORMAÇÕES › GERENCIAR CATEGORIAS.</Text>
        )}
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao]} onPress={handleAdicionarLutador}>
          <Text style={styles.textoBotaoMain}>SALVAR LUTADOR</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "gerenciar_lutadores") return (
      <View style={styles.container}>
        <Text style={styles.titulo}>GERENCIAR LUTADORES</Text>
        <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
          {!categoria ? (
            listarCategorias().map(cat => (
              <TouchableOpacity key={cat} style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => setCategoria(cat)}>
                <Text style={styles.textoBotaoCardLista}>{cat}</Text>
              </TouchableOpacity>
            ))
          ) : !lutadorSendoEditado ? (
            <>
              <Text style={styles.subtituloInformativo}>CLIQUE NAS SETAS ▲/▼ PARA REORDENAR O RANKING:</Text>
              {(lutadoresDB[categoria] || []).map((n, index) => (
                <ItemLutadorDeslocavel
                  key={n}
                  nome={n}
                  index={index}
                  totalItens={(lutadoresDB[categoria] || []).length}
                  onReorder={handleReordenarLutadores}
                  onEdit={() => { setLutadorSendoEditado(n); setNovoLutadorNome(n); setCategoriaSelecionada(categoria); setCategoriaAntigaEditado(categoria); }}
                  onDelete={() => acionarExclusaoLutador(n, categoria)}
                />
              ))}
              <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao, {marginTop: 20}]} onPress={() => setCategoria(null)}>
                <Text style={styles.textoBotaoVoltarBorda}>VOLTAR CATEGORIAS</Text>
              </TouchableOpacity>
            </>
          ) : (
            <View style={[styles.cardFormularioEdicao, styles.elementoLarguraPadrao]}>
              <Text style={[styles.titulo, {fontSize: 18, color: '#E11D2E'}]}>EDITANDO: {lutadorSendoEditado}</Text>
              <Text style={styles.nomeLabel}>NOME DO LUTADOR:</Text>
              <TextInput style={styles.inputPremium} placeholder="NOME DO LUTADOR" placeholderTextColor="#55555F" value={novoLutadorNome} onChangeText={setNovoLutadorNome} />
              <Text style={[styles.nomeLabel, {marginTop: 15}]}>MUDAR CATEGORIA:</Text>
              <View style={styles.rowCategoriasTabs}>
                {listarCategoriasReais().map(cat => (
                  <TouchableOpacity key={cat} style={[styles.tabCategoriaBotao, categoriaSelecionada === cat && styles.tabCategoriaAtiva]} onPress={() => setCategoriaSelecionada(cat)}>
                    <Text style={styles.textoBotaoAlvo}>{cat}</Text>
                  </TouchableOpacity>
                ))}
              </View>
              <TouchableOpacity style={styles.botaoMainNeon} onPress={handleSalvarEdicaoLutador}>
                <Text style={styles.textoBotaoMain}>SALVAR ALTERAÇÕES</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.botaoVoltarCinzaBorda} onPress={() => setLutadorSendoEditado(null)}>
                <Text style={styles.textoBotaoVoltarBorda}>CANCELAR EDIÇÃO</Text>
              </TouchableOpacity>
            </View>
          )}
        </ScrollView>
        {!lutadorSendoEditado && (
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>{ setCategoria(null); setTela("gerenciar_informacoes"); }}>
            <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
          </TouchableOpacity>
        )}
      </View>
    );
    if (tela === "lixeira") return (
      <View style={styles.container}>
        <View style={styles.rowTituloComIcone}>
          <IconeLixeira cor="#E11D2E" />
          <Text style={[styles.titulo, {marginBottom: 0, marginLeft: 12, width: undefined}]}>LIXEIRA</Text>
        </View>
        <View style={[styles.rowCategoriasTabs, styles.elementoLarguraPadrao, {marginBottom: 12}]}>
          <TouchableOpacity style={[styles.tabCategoriaBotao, abaLixeira === "lutadores" && styles.tabCategoriaAtiva]} onPress={() => setAbaLixeira("lutadores")}>
            <Text style={styles.textoBotaoAlvo}>LUTADORES ({lixeiraDB.length})</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.tabCategoriaBotao, abaLixeira === "eventos" && styles.tabCategoriaAtiva]} onPress={() => setAbaLixeira("eventos")}>
            <Text style={styles.textoBotaoAlvo}>EVENTOS ({lixeiraEventosDB.length})</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
          {abaLixeira === "lutadores" ? (
            (!lixeiraDB || lixeiraDB.length === 0) ? (
              <Text style={styles.textoListaVazia}>A LIXEIRA DE LUTADORES ESTÁ VAZIA.</Text>
            ) : (
              lixeiraDB.map((item, idx) => (
                <View key={idx} style={[styles.botaoLixeiraItemCard, styles.elementoLarguraPadrao]}>
                  <TouchableOpacity style={{flex: 1}} onPress={() => { setLutadorSelecionadoLixeira(item); setModalOpcoesLixeira(true); }}>
                    <Text style={styles.textoLutadorLixeiraNome}>{item.nome}</Text>
                    <Text style={styles.textoLutadorLixeiraSub}>{item.categoria}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.botaoLixeiraApagarDefinitivo}
                    onPress={() => { setLutadorSelecionadoLixeira(item); setModalApagarDefinitivoConfirm(true); }}
                  >
                    <IconeLixeira cor="#FFF" />
                  </TouchableOpacity>
                </View>
              ))
            )
          ) : (
            (!lixeiraEventosDB || lixeiraEventosDB.length === 0) ? (
              <Text style={styles.textoListaVazia}>A LIXEIRA DE EVENTOS ESTÁ VAZIA.</Text>
            ) : (
              lixeiraEventosDB.map((ev, idx) => (
                <View key={ev.excluidoEm || idx} style={[styles.botaoLixeiraItemCard, styles.elementoLarguraPadrao]}>
                  <TouchableOpacity style={{flex: 1}} onPress={() => { setEventoLixeiraSel(ev); setModalOpcoesLixeiraEvento(true); }}>
                    <Text style={styles.textoLutadorLixeiraNome}>{ev.nome}</Text>
                    <Text style={styles.textoLutadorLixeiraSub}>
                      {(ev.lutasAgendadas || []).length} LUTA(S) • {ev.origemLixeira === "andamento" ? "ESTAVA EM ANDAMENTO" : "ESTAVA NO HISTÓRICO"}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.botaoLixeiraApagarDefinitivo}
                    onPress={() => {
                      setEventoLixeiraSel(ev);
                      setModalConfirmarGeral({ visivel: true, titulo: "EXCLUIR DEFINITIVAMENTE?", mensagem: "ISSO APAGARÁ O EVENTO DA LIXEIRA PARA SEMPRE.", acaoSim: () => {
                        setLixeiraEventosDB(prev => prev.filter(e => e.excluidoEm !== ev.excluidoEm));
                        setEventoLixeiraSel(null);
                        mostrarAlertaCustom("SUCESSO", "EVENTO EXCLUÍDO PERMANENTEMENTE.");
                      }});
                    }}
                  >
                    <IconeLixeira cor="#FFF" />
                  </TouchableOpacity>
                </View>
              ))
            )
          )}
        </ScrollView>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={() => setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "visualizar_historico_limbo") {
      const lutasLixeira = historicoEventos.reduce((acc, ev) => acc.concat(ev.lutasAgendadas || []), []).filter(l => l && l.resultado && (l.lutador1 === itemSelecionado || l.lutador2 === itemSelecionado));
      return (
        <View style={styles.container}>
          <Text style={styles.titulo}>HISTÓRICO INDIVIDUAL (LIXEIRA)</Text>
          <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
            <Text style={styles.vencedorNomePlacard}>{itemSelecionado}</Text>
            <Text style={styles.cartelTxtDestaque}>{getCartel(itemSelecionado)}</Text>
            {lutasLixeira.map((l, i) => (
              <View key={i} style={[styles.subCardLutaHistorica, styles.elementoLarguraPadrao]}>
                <Text style={{color: l.resultado.vencedor === itemSelecionado ? '#22C55E' : '#E11D2E', fontWeight: '900', fontSize: 12, marginBottom: 6, letterSpacing: 1}}>{l.resultado.vencedor === itemSelecionado ? "VITÓRIA" : "DERROTA"}</Text>
                <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                  <Text style={styles.confrontoTextoCards}>{l.lutador1} VS {l.lutador2}{l.contagem ? ` ${l.contagem}` : ""}</Text>
                  {l.cinturao && <IconeCinturao cor={l.corCinturao} />}
                </View>
                <Text style={styles.nomeEventoSubCard}>{l.resultado.nomeDoEvento}</Text>
                <Text style={styles.metodoDetalheSubCard}>{l.resultado.metodo} {l.resultado.pointsDec ? `(${l.resultado.pointsDec})` : (l.resultado.metodo === "DEC" ? "" : `- R${l.resultado.round} (T:${l.resultado.turno})`)}</Text>
                {!!textoStats(l.resultado.stats) && <Text style={styles.linhaStatsTxt}>{textoStats(l.resultado.stats)}</Text>}
              </View>
            ))}
          </ScrollView>
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={() => { setTela("lixeira"); setItemSelecionado(null); }}>
            <Text style={styles.textoBotaoVoltarBorda}>VOLTAR PARA LIXEIRA</Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tela === "selecao_tipo_evento") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>TIPO DE EVENTO</Text>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setEventoEmAndamento({ nome: `UFC ${getProximoNumerado()}`, idEvento: String(Date.now()), lutasAgendadas: [] }); setCategoria(null); setTela("agendar_lutas"); }}>
          <Text style={styles.textoBotaoCardLista}>UFC NUMERADO</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setEventoEmAndamento({ nome: "UFC FIGHT NIGHT", idEvento: String(Date.now()), lutasAgendadas: [] }); setCategoria(null); setTela("agendar_lutas"); }}>
          <Text style={styles.textoBotaoCardLista}>UFC FIGHT NIGHT</Text>
        </TouchableOpacity>
        <View style={[styles.divisorLine, styles.elementoLarguraPadrao]} />
        <TextInput style={[styles.inputPremium, styles.elementoLarguraPadrao]} placeholder="NOME ESPECIAL (EX: MUNICH)" placeholderTextColor="#55555F" value={inputEventoEspecial} onChangeText={setInputEventoEspecial} />
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao]} onPress={() => { if(!inputEventoEspecial) return; setEventoEmAndamento({ nome: `UFC ${inputEventoEspecial}`, idEvento: String(Date.now()), lutasAgendadas: [] }); setInputEventoEspecial(""); setCategoria(null); setTela("agendar_lutas"); }}>
          <Text style={styles.textoBotaoMain}>CRIAR ESPECIAL</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "agendar_lutas") {
      const numLutas = eventoEmAndamento?.lutasAgendadas?.length || 0;
      const labelAtual = getLabelLutaPorArrayOriginal(lutador1, lutador2);
      const lutadoresOcupados = (eventoEmAndamento?.lutasAgendadas || []).reduce((acc, l) => acc.concat([l.lutador1, l.lutador2]), []);
      return (
        <View style={styles.container}>
          <Text style={[styles.titulo, {color: modoTreino ? '#FFF' : '#E11D2E'}]}>{modoTreino ? "TREINO: SELECIONE LUTADORES" : `AGENDAR: ${labelAtual}`}</Text>
          {!modoTreino && numLutas > 0 && (
            <Text style={{color: '#8A8A98', fontSize: 12, fontWeight: '700', textAlign: 'center', marginBottom: 10, letterSpacing: 1}}>LUTAS AGENDADAS ATÉ AGORA: {numLutas}</Text>
          )}
          <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
            {!categoria ? (listarCategorias().map(cat => (
              <TouchableOpacity key={cat} style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => setCategoria(cat)}>
                <Text style={styles.textoBotaoCardLista}>ESCOLHER DA CAT. {cat}</Text>
              </TouchableOpacity>
            ))) : (
              <>
                {(lutadoresDB[categoria] || []).map(n => {
                  const ocupado = !modoTreino && lutadoresOcupados.includes(n);
                  const selecionado = lutador1 === n || lutador2 === n;
                  return (
                    <TouchableOpacity
                      key={n}
                      disabled={ocupado}
                      style={[styles.botaoListaCard, styles.elementoLarguraPadrao, selecionado && styles.botaoListaCardSelecionado, ocupado && {opacity: 0.15}]}
                      onPress={() => {
                        if(lutador1 === n) setLutador1(null);
                        else if(lutador2 === n) setLutador2(null);
                        else if(!lutador1) setLutador1(n);
                        else if(!lutador2) setLutador2(n);
                      }}
                    >
                      <Text style={[styles.textoBotaoCardLista, selecionado && {color: '#FFF'}]}>{n}</Text>
                    </TouchableOpacity>
                  );
                })}
                <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={() => setCategoria(null)}>
                  <Text style={styles.textoBotaoVoltarBorda}>VOLTAR CATEGORIAS</Text>
                </TouchableOpacity>
              </>
            )}
            {lutador1 && lutador2 && (
              <View style={[styles.cardConfiguracaoCombate, styles.elementoLarguraPadrao]}>
                {!modoTreino && (
                  <>
                    <Text style={styles.tituloSecundarioConfig}>CONFIGURAR DISPUTA</Text>
                    <View style={styles.rowBotoesCinturao}>
                      <TouchableOpacity style={[styles.botaoCinturaoOpcao, valeCinturao === 'gold' && {backgroundColor: '#F5C451', borderColor: '#FFF'}]} onPress={() => setValeCinturao(valeCinturao === 'gold' ? null : 'gold')}>
                        <Text style={[styles.textoBotaoCint, valeCinturao === 'gold' && {color: '#000'}]}>CINTURÃO</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={[styles.botaoCinturaoOpcao, valeCinturao === 'silver' && {backgroundColor: '#E2E8F0', borderColor: '#FFF'}]} onPress={() => setValeCinturao(valeCinturao === 'silver' ? null : 'silver')}>
                        <Text style={[styles.textoBotaoCint, valeCinturao === 'silver' && {color: '#000'}]}>CINTURÃO BMF</Text>
                      </TouchableOpacity>
                    </View>
                  </>
                )}
                <TouchableOpacity style={styles.botaoMainNeon} onPress={() => {
                  if(modoTreino) { iniciarLuta(); } else {
                    const numContagem = getContagemLutas(lutador1, lutador2);
                    setEventoEmAndamento(prev => ({
                      ...prev,
                      lutasAgendadas: [...(prev?.lutasAgendadas || []), { idLuta: String(Date.now()), lutador1, lutador2, contagem: numContagem, status: "Pendente", cinturao: valeCinturao !== null, corCinturao: valeCinturao }]
                    }));
                    setLutador1(null); setLutador2(null); setCategoria(null); setValeCinturao(null);
                    mostrarAlertaCustom("SUCESSO", "CONFRONTO AGENDADO COM SUCESSO!");
                  }
                }}><Text style={styles.textoBotaoMain}>{modoTreino ? "INICIAR TREINO" : "AGENDAR COMBATE"}</Text></TouchableOpacity>
              </View>
            )}
          </ScrollView>
          {!modoTreino && numLutas > 0 && (
            <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao, {backgroundColor: '#16A34A', shadowColor: '#16A34A', marginTop: 15}]} onPress={() => { setTela("continuar_evento"); }}>
              <Text style={styles.textoBotaoMain}>FINALIZAR CARD ({numLutas} LUTAS)</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>{
            setLutador1(null); setLutador2(null); setCategoria(null); setValeCinturao(null);
            setTela("menu_inicial");
          }}>
            <Text style={styles.textoBotaoVoltarBorda}>CANCELAR E VOLTAR</Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tela === "luta") {
      const alvoBloqueado = (id) => { if (vezDeQuem === 1) return id === 1; if (vezDeQuem === 2) return id === 2; return false; };
      const tituloEvento = eventoEmAndamento?.nome ? eventoEmAndamento.nome : "EVENTO";
      const COR1 = '#E11D2E';
      const COR2 = '#3B82F6';
      return (
        <View style={styles.containerDashboardLuta}>
          <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
            {modoTreino && <View style={styles.tagTreinoBadge}><Text style={styles.tagTreinoTxt}>MODO TREINO - NÃO SALVA</Text></View>}
            <Text style={styles.headerLutaTransmissao}>{modoTreino ? "SPARRING INDIVIDUAL" : tituloEvento} | {getLabelLutaPorArrayOriginal(lutador1, lutador2)}</Text>
            <View style={styles.roundBadge}>
              <Text style={styles.roundContadorGlobal}>ROUND {roundAtual} / {rounds}  •  TURNO {getTurnoAtual()} / 10</Text>
            </View>
            {roundScores.length > 0 && (
              <Text style={styles.headerLutaTransmissao}>
                {roundScores.map(r => `R${r.round}: ${r.p1}-${r.p2}`).join("    ")}
              </Text>
            )}

            <View style={[styles.painelLutadorStatus, styles.elementoLarguraPadrao, {borderLeftColor: COR1}]}>
              <View style={styles.rowStatusLutadorHeader}>
                <View style={styles.rowNomeEHp}>
                  <Text style={styles.nomeLutadorDashboard}>{lutador1}</Text>
                  <Text style={styles.hpNumericoTexto}>{vida1} HP</Text>
                </View>
                <Text style={styles.turnoLabelContador}>TURNOS: {turnos1}</Text>
              </View>
              <View style={styles.containerBarraFundoGauge}>
                <Animated.View style={[styles.barraHPGauge, { width: vidaAnim1.interpolate({ inputRange: [0, vidaMax], outputRange: ["0%", "100%"] }), backgroundColor: vidaAnim1.interpolate({ inputRange: [0, vidaMax / 2, vidaMax], outputRange: ["#E11D2E", "#EAB308", "#22C55E"] }) }]} />
              </View>
              <View style={styles.rowStats}>
                <ContadorStat rotulo="CRÍTICOS" valor={stats.c1} cor="#F5C451" onMais={() => ajustarStat('c1', 1)} onMenos={() => ajustarStat('c1', -1)} />
                <ContadorStat rotulo="KNOCKDOWNS" valor={stats.k1} cor="#FB923C" onMais={() => ajustarStat('k1', 1)} onMenos={() => ajustarStat('k1', -1)} />
              </View>
              <TouchableOpacity disabled={vezDeQuem === 2 || roundAcabouAviso} style={[styles.botaoTurnoAcao, (vezDeQuem === 2 || roundAcabouAviso) && { opacity: 0.15 }]} onPress={() => registrarTurno(1)}>
                <Text style={styles.textoBotaoTurno}>REGISTRAR TURNO {lutador1}</Text>
              </TouchableOpacity>
            </View>

            <View style={[styles.painelLutadorStatus, styles.elementoLarguraPadrao, {marginTop: 14, borderLeftColor: COR2}]}>
              <View style={styles.rowStatusLutadorHeader}>
                <View style={styles.rowNomeEHp}>
                  <Text style={styles.nomeLutadorDashboard}>{lutador2}</Text>
                  <Text style={styles.hpNumericoTexto}>{vida2} HP</Text>
                </View>
                <Text style={styles.turnoLabelContador}>TURNOS: {turnos2}</Text>
              </View>
              <View style={styles.containerBarraFundoGauge}>
                <Animated.View style={[styles.barraHPGauge, { width: vidaAnim2.interpolate({ inputRange: [0, vidaMax], outputRange: ["0%", "100%"] }), backgroundColor: vidaAnim2.interpolate({ inputRange: [0, vidaMax / 2, vidaMax], outputRange: ["#E11D2E", "#EAB308", "#22C55E"] }) }]} />
              </View>
              <View style={styles.rowStats}>
                <ContadorStat rotulo="CRÍTICOS" valor={stats.c2} cor="#F5C451" onMais={() => ajustarStat('c2', 1)} onMenos={() => ajustarStat('c2', -1)} />
                <ContadorStat rotulo="KNOCKDOWNS" valor={stats.k2} cor="#FB923C" onMais={() => ajustarStat('k2', 1)} onMenos={() => ajustarStat('k2', -1)} />
              </View>
              <TouchableOpacity disabled={vezDeQuem === 1 || roundAcabouAviso} style={[styles.botaoTurnoAcao, (vezDeQuem === 1 || roundAcabouAviso) && { opacity: 0.15 }]} onPress={() => registrarTurno(2)}>
                <Text style={styles.textoBotaoTurno}>REGISTRAR TURNO {lutador2}</Text>
              </TouchableOpacity>
            </View>

            <View style={[styles.rowDesfazer, styles.elementoLarguraPadrao]}>
              <TouchableOpacity disabled={pilhaTurnos.length === 0} style={[styles.botaoDesfazer, pilhaTurnos.length === 0 && {opacity: 0.25}]} onPress={desfazerTurno}>
                <Text style={styles.textoDesfazer}>↶ VOLTAR TURNO</Text>
              </TouchableOpacity>
              <TouchableOpacity disabled={pilhaDano.length === 0} style={[styles.botaoDesfazer, pilhaDano.length === 0 && {opacity: 0.25}]} onPress={desfazerDano}>
                <Text style={styles.textoDesfazer}>↶ VOLTAR DANO</Text>
              </TouchableOpacity>
            </View>

            {roundAcabouAviso ? (
              <View style={[styles.painelFimRoundAlerta, styles.elementoLarguraPadrao]}>
                <Text style={styles.textoFimRoundAlerta}>FIM DO ROUND {roundAtual}!</Text>
                <TouchableOpacity style={[styles.botaoMainNeon, {width: '100%'}]} onPress={() => setTela("pontuacao_round")}>
                  <Text style={styles.textoBotaoMain}>MARCAR PONTUAÇÃO DO ROUND</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <View style={[styles.divisorLine, styles.elementoLarguraPadrao]} />
                <TextInput style={[styles.inputPremium, styles.elementoLarguraPadrao]} placeholder="INSERIR VALOR DE DANO" placeholderTextColor="#55555F" value={dano} onChangeText={setDano} keyboardType="numeric" onFocus={() => setMetodoSelecionado('DANO')} />
                <View style={[styles.rowTaticoAlvo, styles.elementoLarguraPadrao]}>
                  <TouchableOpacity disabled={alvoBloqueado(1)} style={[styles.botaoAlvoTatico, alvoSelecionado===1 && styles.botaoAlvoTaticoAtivo, alvoBloqueado(1) && {opacity: 0.1}]} onPress={() => setAlvoSelecionado(prev => prev === 1 ? null : 1)}>
                    <Text style={styles.textoBotaoAlvo}>ALVO: {lutador1}</Text>
                  </TouchableOpacity>
                  <TouchableOpacity disabled={alvoBloqueado(2)} style={[styles.botaoAlvoTatico, alvoSelecionado===2 && styles.botaoAlvoTaticoAtivo, alvoBloqueado(2) && {opacity: 0.1}]} onPress={() => setAlvoSelecionado(prev => prev === 2 ? null : 2)}>
                    <Text style={styles.textoBotaoAlvo}>ALVO: {lutador2}</Text>
                  </TouchableOpacity>
                </View>
                <View style={[styles.rowMetodosAtaque, styles.elementoLarguraPadrao]}>
                  <TouchableOpacity style={[styles.botaoMetodoFim, styles.metodoKo, metodoSelecionado==='KO' && styles.metodoSelecionadoBorda]} onPress={() => setMetodoSelecionado(prev => prev === 'KO' ? null : 'KO')}><Text style={styles.textoMetodoCardFim}>KO</Text></TouchableOpacity>
                  <TouchableOpacity style={[styles.botaoMetodoFim, styles.metodoTko, metodoSelecionado==='TKO' && styles.metodoSelecionadoBorda]} onPress={() => setMetodoSelecionado(prev => prev === 'TKO' ? null : 'TKO')}><Text style={styles.textoMetodoCardFim}>TKO</Text></TouchableOpacity>
                  <TouchableOpacity style={[styles.botaoMetodoFim, styles.metodoSub, metodoSelecionado==='SUB' && styles.metodoSelecionadoBorda]} onPress={() => setMetodoSelecionado(prev => prev === 'SUB' ? null : 'SUB')}><Text style={styles.textoMetodoCardFim}>SUB</Text></TouchableOpacity>
                </View>
                <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao, {marginTop: 15}]} onPress={() => {
                  if (!alvoSelecionado || !metodoSelecionado) return;
                  if (metodoSelecionado === 'DANO') {
                    const v = parseInt(dano); if (!v) return;
                    aplicarDano(alvoSelecionado, v);
                    setDano("");
                  } else {
                    // KO / TKO / SUB: pede confirmação antes de encerrar a luta
                    setModalFinalizacao({ visivel: true, metodo: metodoSelecionado, alvo: alvoSelecionado });
                  }
                }}><Text style={styles.textoBotaoMain}>CONFIRMAR AÇÃO COMBATE</Text></TouchableOpacity>
              </>
            )}
          </ScrollView>
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao, {marginTop: 10}]} onPress={()=>setModalAbandonar(true)}>
            <Text style={styles.textoBotaoVoltarBorda}>ABANDONAR LUTA</Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tela === "pontuacao_round") {
      const notas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
      const bloco = (lado, nome, sel, outro) => (
        <View style={[styles.elementoLarguraPadrao, {marginBottom: 18}]}>
          <Text style={styles.nomeLabel}>{nome}</Text>
          <View style={styles.rowCategoriasTabs}>
            {notas.map(v => {
              const bloqueado = v === 10 && outro === 10;
              return (
                <TouchableOpacity
                  key={v}
                  disabled={bloqueado}
                  style={[styles.tabCategoriaBotao, {minWidth: '17%', width: '17%', flexGrow: 0}, sel === v && styles.tabCategoriaAtiva, bloqueado && {opacity: 0.15}]}
                  onPress={() => escolherPontoRound(lado, v)}
                >
                  <Text style={styles.textoBotaoAlvo}>{v}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      );
      return (
        <View style={styles.containerCentro}>
          <Text style={styles.titulo}>PONTUAÇÃO DO ROUND {roundAtual}</Text>
          <Text style={styles.subtituloInformativo}>MÁXIMO 10. SE UM TIVER 10, O OUTRO TEM NO MÁXIMO 9.</Text>
          {bloco(1, lutador1, ptsRound1, ptsRound2)}
          {bloco(2, lutador2, ptsRound2, ptsRound1)}
          <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao]} onPress={confirmarPontuacaoRound}>
            <Text style={styles.textoBotaoMain}>{roundAtual < rounds ? `CONFIRMAR E IR PARA ROUND ${roundAtual + 1}` : "CONFIRMAR E IR PARA A DECISÃO"}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={() => setTela("luta")}>
            <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tela === "escolher_vencedor_decisao") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>FIM DE LUTA: DECISÃO</Text>
        <Text style={styles.subtituloInformativo}>SELECIONE O VENCEDOR NA VISÃO DOS JUÍZES COLISEU:</Text>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setVencDecisaoTemp(lutador1); setTela("pontuacao_juizes"); }}>
          <Text style={styles.textoBotaoCardLista}>VENCEDOR: {lutador1}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => { setVencDecisaoTemp(lutador2); setTela("pontuacao_juizes"); }}>
          <Text style={styles.textoBotaoCardLista}>VENCEDOR: {lutador2}</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoListaCard, styles.elementoLarguraPadrao, {borderColor: '#2A2A35'}]} onPress={() => { setVencDecisaoTemp("Empate"); setTela("pontuacao_juizes"); }}>
          <Text style={styles.textoBotaoCardLista}>EMPATE CARD</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "pontuacao_juizes") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>PONTUAÇÃO DA LUTA</Text>
        <View style={[styles.rowPlacarJuizesContainer, styles.elementoLarguraPadrao]}>
          <View style={styles.colunaPlacarLutador}>
            <Text style={styles.nomeLutadorPlacarJuizes}>{lutador1}</Text>
            <TextInput style={styles.inputPontosCard} placeholder="00" placeholderTextColor="#444" keyboardType="numeric" value={pointsL1} onChangeText={setPointsL1} maxLength={2} />
          </View>
          <Text style={styles.textoVersusJuizes}>X</Text>
          <View style={styles.colunaPlacarLutador}>
            <Text style={styles.nomeLutadorPlacarJuizes}>{lutador2}</Text>
            <TextInput style={styles.inputPontosCard} placeholder="00" placeholderTextColor="#444" keyboardType="numeric" value={pontosL2} onChangeText={setPontosL2} maxLength={2} />
          </View>
        </View>
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao, {marginTop: 30}]} onPress={() => {
          const score = (pointsL1 && pontosL2) ? `${pointsL1}-${pontosL2}` : "";
          if (vencDecisaoTemp === "Empate") finalizarLuta("EMPATE", "Empate", "-", roundAtual, score);
          else finalizarLuta("DEC", vencDecisaoTemp, "-", roundAtual, score);
        }}><Text style={styles.textoBotaoMain}>FINALIZAR RESULTADO CARD</Text></TouchableOpacity>
      </View>
    );
    if (tela === "resultado") return (
      <View style={styles.containerCentro}>
        {modoTreino && <Text style={styles.subtituloInformativo}>CONCLUÍDO NO MODO SPARRING</Text>}
        <Text style={[styles.titulo, {color: '#E11D2E', letterSpacing: 4}]}>RESULTADO OFICIAL</Text>
        <View style={[styles.cardResultado, styles.elementoLarguraPadrao]}>
          <Text style={styles.vencedorNomePlacard}>{resultado?.vencedor}</Text>
          <Text style={styles.metodoTxtDestaque}>{resultado?.metodo} {resultado?.pointsDec || ""}</Text>
          <Text style={styles.subMetodoTxtDetalhe}>{resultado?.metodo !== "DEC" && resultado?.metodo !== "EMPATE" ? `ROUND ${resultado?.round} - TURNO: ${resultado?.turno}` : ""}</Text>
          {!!textoStats(resultado?.stats) && <Text style={[styles.linhaStatsTxt, {textAlign: 'center', marginTop: 12}]}>{textoStats(resultado?.stats)}</Text>}
          {resultado?.roundScores?.length > 0 && (
            <Text style={[styles.linhaStatsTxt, {textAlign: 'center', marginTop: 8}]}>
              {resultado.roundScores.map(r => `R${r.round}: ${r.p1}-${r.p2}`).join("  •  ")}
            </Text>
          )}
        </View>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={concluirLutaEResetar}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "hist_eventos") return (
      <View style={styles.container}>
        <Text style={styles.titulo}>HISTÓRICO DE EVENTOS</Text>
        <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
          {historicoEventos.map((ev, i) => {
            if (!ev) return null;
            const lutasOrdenadas = ordenarLutasDoEvento(ev.lutasAgendadas, ev.nome);
            return (
              <View key={i} style={[styles.cardEventoCompletoBox, styles.elementoLarguraPadrao]}>
                <View style={styles.headerCardEventoBox}>
                  <Text style={styles.nomeEventoTituloBox}>{ev.nome}</Text>
                  <TouchableOpacity onPress={() => setModalConfirmarGeral({ visivel: true, titulo: "EXCLUIR EVENTO", mensagem: "O EVENTO SERÁ MOVIDO PARA A LIXEIRA DE EVENTOS, ONDE VOCÊ PODE RECUPERÁ-LO. CONFIRMA?", acaoSim: () => { excluirEventoHistorico(ev, i); }})}>
                    <Text style={styles.textoExcluirCardAction}>EXCLUIR</Text>
                  </TouchableOpacity>
                </View>
                {lutasOrdenadas.map((l, j) => (
                  <View key={j} style={styles.subCardLutaHistorica}>
                    <View style={styles.rowLutaHistBox}>
                      <View style={{flex: 1}}>
                        <Text style={styles.confrontoTextoCards}>{l.lutador1} <Text style={{color: '#E11D2E'}}>VS</Text> {l.lutador2}{l.contagem ? ` ${l.contagem}` : ""}</Text>
                      </View>
                      {l.cinturao && <IconeCinturao cor={l.corCinturao} />}
                    </View>
                    <View style={styles.resultadoContainerBox}>
                      <Text style={styles.vencedorLabelBox}>VENCEDOR: <Text style={{color: '#FFF'}}>{l.resultado?.vencedor}</Text></Text>
                      <Text style={styles.detalheResultadoBox}>{l.resultado?.metodo} {l.resultado?.pointsDec ? `(${l.resultado.pointsDec})` : (l.resultado?.metodo === "DEC" || l.resultado?.metodo === "EMPATE" ? "" : `- R${l.resultado?.round} (T:${l.resultado?.turno})`)}</Text>
                      {!!textoStats(l.resultado?.stats) && <Text style={styles.linhaStatsTxt}>{textoStats(l.resultado?.stats)}</Text>}
                      {l.resultado?.roundScores?.length > 0 && (
                        <Text style={styles.linhaStatsTxt}>{l.resultado.roundScores.map(r => `R${r.round}: ${r.p1}-${r.p2}`).join("  •  ")}</Text>
                      )}
                    </View>
                  </View>
                ))}
              </View>
            );
          })}
        </ScrollView>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "hist_lutadores") {
      const lutasAtuais = historicoEventos.reduce((acc, ev) => acc.concat(ev.lutasAgendadas || []), []).filter(l => l && l.resultado && (l.lutador1 === itemSelecionado || l.lutador2 === itemSelecionado));
      return (
        <View style={styles.container}>
          <Text style={styles.titulo}>HISTÓRICO DE LUTADORES</Text>
          <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
            {!categoria ? (listarCategorias().map(cat => (
              <TouchableOpacity key={cat} style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => setCategoria(cat)}>
                <Text style={styles.textoBotaoCardLista}>{cat}</Text>
              </TouchableOpacity>
            ))) : !itemSelecionado ? (
              <>{(lutadoresDB[categoria] || []).map(n => (
                <TouchableOpacity key={n} style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => setItemSelecionado(n)}>
                  <Text style={styles.textoBotaoCardLista}>{n} <Text style={{color:'#8A8A98', fontSize: 13}}>({getCartel(n)})</Text></Text>
                </TouchableOpacity>
              ))}
              <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao, {marginTop: 20}]} onPress={() => setCategoria(null)}>
                <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
              </TouchableOpacity></>
            ) : (
              <View style={{width: '100%', alignItems: 'center'}}>
                <Text style={styles.vencedorNomePlacard}>{itemSelecionado}</Text>
                <Text style={styles.cartelTxtDestaque}>{getCartel(itemSelecionado)}</Text>
                {lutasAtuais.map((l, i) => (
                  <View key={i} style={[styles.subCardLutaHistorica, styles.elementoLarguraPadrao]}>
                    <Text style={{color: l.resultado.vencedor === itemSelecionado ? '#22C55E' : '#E11D2E', fontWeight: '900', fontSize: 12, marginBottom: 5}}>{l.resultado.vencedor === itemSelecionado ? "VITÓRIA" : "DERROTA"}</Text>
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                      <Text style={styles.confrontoTextoCards}>{l.lutador1} VS {l.lutador2}{l.contagem ? ` ${l.contagem}` : ""}</Text>
                      {l.cinturao && <IconeCinturao cor={l.corCinturao} />}
                    </View>
                    <Text style={styles.nomeEventoSubCard}>{l.resultado.nomeDoEvento}</Text>
                    <Text style={styles.metodoDetalheSubCard}>{l.resultado.metodo} {l.resultado.pointsDec ? `(${l.resultado.pointsDec})` : (l.resultado.metodo === "DEC" ? "" : `- R${l.resultado.round} (T:${l.resultado.turno})`)}</Text>
                    {!!textoStats(l.resultado.stats) && <Text style={styles.linhaStatsTxt}>{textoStats(l.resultado.stats)}</Text>}
                  </View>
                ))}
                <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={() => setItemSelecionado(null)}>
                  <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
                </TouchableOpacity>
              </View>
            )}
          </ScrollView>
          <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
            <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
          </TouchableOpacity>
        </View>
      );
    }
    if (tela === "continuar_evento") return (
      <View style={styles.container}>
        <View style={[styles.elementoLarguraPadrao, {flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:20}]}>
          <Text style={[styles.titulo, {marginBottom:0, width: undefined, flex: 1, textAlign: 'left'}]}>{eventoEmAndamento?.nome}</Text>
          <TouchableOpacity onPress={() => setModalConfirmarGeral({ visivel: true, titulo: "EXCLUIR EVENTO", mensagem: "O EVENTO ATUAL SERÁ MOVIDO PARA A LIXEIRA DE EVENTOS, ONDE VOCÊ PODE RECUPERÁ-LO. CONFIRMA?", acaoSim: excluirEventoAtual })}>
            <Text style={styles.textoExcluirCardAction}>EXCLUIR</Text>
          </TouchableOpacity>
        </View>
        <ScrollView style={{width: '100%'}} contentContainerStyle={styles.globalContentContainer} showsVerticalScrollIndicator={false}>
          {ordenarLutasDoEvento(eventoEmAndamento?.lutasAgendadas, eventoEmAndamento?.nome).map((l, indexVisual) => {
            if (!l) return null;
            const isInterrompida = l.status === "Interrompida";
            return (
              <View key={l.idLuta || indexVisual} style={[styles.cardLutaAgendadaBox, styles.elementoLarguraPadrao]}>
                <TouchableOpacity
                  disabled={l.status === "Finalizada"}
                  style={{flex: 1}}
                  onPress={() => {
                    setLutador1(l.lutador1); setLutador2(l.lutador2); setIdLutaAtiva(l.idLuta);
                    if (isInterrompida) { setModalRetornarLuta(true); } else { iniciarLuta(); }
                  }}
                >
                  <Text style={[styles.tagLabelCardLuta, isInterrompida && {color: '#EAB308'}]}>
                    {getLabelLutaPorArrayOriginal(l.lutador1, l.lutador2)} {isInterrompida ? "- INTERROMPIDA" : ""}
                  </Text>
                  <Text style={[styles.nomesCardLutaTxt, l.status === "Finalizada" && {color: '#666'}]}>{l.lutador1} VS {l.lutador2}{l.contagem ? ` ${l.contagem}` : ""} {l.status === "Finalizada" ? "✓" : ""}</Text>
                </TouchableOpacity>
                {l.status !== "Finalizada" && (
                  <TouchableOpacity style={styles.botaoRemoverLutaAgendada} onPress={() => setEventoEmAndamento({...eventoEmAndamento, lutasAgendadas: eventoEmAndamento.lutasAgendadas.filter(item => item.idLuta !== l.idLuta)})}>
                    <Text style={{color: '#E11D2E', fontSize: 11, fontWeight:'900'}}>REMOVER</Text>
                  </TouchableOpacity>
                )}
              </View>
            );
          })}
        </ScrollView>
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao, {marginTop: 15}]} onPress={() => {setCategoria(null); setTela("agendar_lutas");}}><Text style={styles.textoBotaoMain}>ADICIONAR LUTA AO CARD</Text></TouchableOpacity>
        <TouchableOpacity style={[styles.botaoMainNeon, styles.elementoLarguraPadrao, {backgroundColor: '#EA580C', shadowColor: '#EA580C', marginTop: 15}]} onPress={() => setModalConfirmarGeral({ visivel: true, titulo: "ENCERRAR EVENTO", mensagem: "AS LUTAS JÁ REALIZADAS SERÃO ENVIADAS AO HISTÓRICO. AS INCOMPLETAS OU PENDENTES SERÃO DELETADAS PERMANENTEMENTE. CONFIRMA?", acaoSim: handleEncerrarEventoManual })}>
          <Text style={styles.textoBotaoMain}>ENCERRAR EVENTO ATUAL</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela("menu_inicial")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR AO MENU</Text>
        </TouchableOpacity>
      </View>
    );
    if (tela === "escolher_rounds") return (
      <View style={styles.containerCentro}>
        <Text style={styles.titulo}>QUANTIDADE DE ROUNDS?</Text>
        {[3, 5].map(r => (
          <TouchableOpacity key={r} style={[styles.botaoListaCard, styles.elementoLarguraPadrao]} onPress={() => {setRounds(r); setTela("luta")}}>
            <Text style={styles.textoBotaoCardLista}>{r} ROUNDS COMBATE</Text>
          </TouchableOpacity>
        ))}
        <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, styles.elementoLarguraPadrao]} onPress={()=>setTela(modoTreino ? "agendar_lutas" : "continuar_evento")}>
          <Text style={styles.textoBotaoVoltarBorda}>VOLTAR</Text>
        </TouchableOpacity>
      </View>
    );
    return null;
  };

  return (
    <View style={styles.telaDeFundoAbsoluto}>
      <StatusBar barStyle="light-content" backgroundColor="#07070A" />
      <View style={styles.faixaTopoVermelha} />
      <Animated.View style={{ flex: 1, opacity: fadeTela }}>
        {renderTelaConteudo()}
      </Animated.View>
      {menuVisivel && (
        <Modal visible={menuVisivel} transparent animationType="fade">
          <TouchableOpacity style={styles.modalOverlay} onPress={() => setMenuVisivel(false)}>
            <View style={styles.modalMenu}>
              <TouchableOpacity style={styles.menuItem} onPress={() => {setTela("hist_eventos"); setMenuVisivel(false)}}>
                <Text style={styles.menuText}>HISTÓRICO DE EVENTOS</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.menuItem} onPress={() => {setTela("hist_lutadores"); setMenuVisivel(false); setCategoria(null); setItemSelecionado(null)}}>
                <Text style={styles.menuText}>HISTÓRICO DE LUTADORES</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.menuItem, {borderBottomWidth: 0}]} onPress={() => {setAbaLixeira("lutadores"); setTela("lixeira"); setMenuVisivel(false);}}>
                <View style={styles.rowBotaoComIconeEsquerda}>
                  <IconeLixeira cor="#E11D2E" />
                  <Text style={[styles.menuText, {color: '#E11D2E', marginLeft: 10}]}>LIXEIRA</Text>
                </View>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        </Modal>
      )}
      {modalFinalizacao.visivel && (() => {
        const { metodo, alvo } = modalFinalizacao;
        const nomeAlvo = alvo === 1 ? lutador1 : lutador2;
        const nomeVencedor = alvo === 1 ? lutador2 : lutador1;
        const turnoVencedor = getTurnoAtual();
        return (
          <Modal visible={modalFinalizacao.visivel} transparent animationType="fade">
            <View style={styles.modalOverlayCentro}>
              <View style={styles.modalConfirmBox}>
                <Text style={styles.tituloConfirm}>CONFIRMAR GOLPE?</Text>
                <Text style={styles.textoModalMensagem}>
                  {metodo} EM {nomeAlvo}.{"\n"}VENCEDOR: {nomeVencedor} (ROUND {roundAtual} - TURNO {turnoVencedor}).{"\n"}A LUTA SERÁ ENCERRADA.
                </Text>
                <View style={styles.rowBotoesModal}>
                  <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#E11D2E'}]} onPress={() => {
                    setModalFinalizacao({ visivel: false, metodo: null, alvo: null });
                    finalizarLuta(metodo, nomeVencedor, turnoVencedor, roundAtual);
                  }}>
                    <Text style={styles.textoBotaoConfirm}>CONFIRMAR</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth: 1, borderColor: '#2A2A35'}]} onPress={() => setModalFinalizacao({ visivel: false, metodo: null, alvo: null })}>
                    <Text style={styles.textoBotaoConfirm}>CANCELAR</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </Modal>
        );
      })()}
      {modalExcluirConfirm && (
        <Modal visible={modalExcluirConfirm} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>MOVER PARA A LIXEIRA?</Text>
              <Text style={styles.textoModalMensagem}>VOCÊ QUER MESMO FAZER ESSAS ALTERAÇÕES? CASO QUEIRA RETOMAR O LUTADOR(A) VOCÊ PODE RECUPERÁ-LO NA LIXEIRA.</Text>
              <View style={styles.rowBotoesModal}>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#E11D2E'}]} onPress={confirmarMoverParaLixeira}><Text style={styles.textoBotaoConfirm}>SIM</Text></TouchableOpacity>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth: 1, borderColor: '#2A2A35'}]} onPress={() => { setModalExcluirConfirm(false); setLutadorParaExcluir(null); }}><Text style={styles.textoBotaoConfirm}>NÃO</Text></TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
      {modalOpcoesLixeira && (
        <Modal visible={modalOpcoesLixeira} transparent animationType="fade">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>{lutadorSelecionadoLixeira?.nome}</Text>
              <TouchableOpacity style={[styles.botaoMainNeon, {marginVertical: 10}]} onPress={() => { setItemSelecionado(lutadorSelecionadoLixeira.nome); setTela("visualizar_historico_limbo"); setModalOpcoesLixeira(false); }}><Text style={styles.textoBotaoMain}>VER HISTÓRICO DO LUTADOR</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoSecundarioBorda, {borderColor: '#16A34A', marginVertical: 10}]} onPress={() => setModalRecuperarConfirm(true)}><Text style={[styles.textoBotaoSecundario, {color: '#22C55E'}]}>RECUPERÁ-LO</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, {marginTop: 15}]} onPress={() => { setModalOpcoesLixeira(false); setLutadorSelecionadoLixeira(null); }}><Text style={styles.textoBotaoVoltarBorda}>FECHAR</Text></TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      {modalOpcoesLixeiraEvento && (
        <Modal visible={modalOpcoesLixeiraEvento} transparent animationType="fade">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>{eventoLixeiraSel?.nome}</Text>
              <Text style={styles.textoModalMensagem}>{(eventoLixeiraSel?.lutasAgendadas || []).length} LUTA(S) NESTE EVENTO.</Text>
              <TouchableOpacity style={[styles.botaoSecundarioBorda, {borderColor: '#16A34A', marginVertical: 8}]} onPress={() => {
                setModalOpcoesLixeiraEvento(false);
                setModalConfirmarGeral({ visivel: true, titulo: "RECUPERAR EVENTO", mensagem: "VOCÊ QUER MESMO RECUPERAR ESTE EVENTO?", acaoSim: recuperarEventoDaLixeira });
              }}><Text style={[styles.textoBotaoSecundario, {color: '#22C55E'}]}>RECUPERAR EVENTO</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoSecundarioBorda, {borderColor: '#E11D2E', marginVertical: 8}]} onPress={() => {
                setModalOpcoesLixeiraEvento(false);
                setModalConfirmarGeral({ visivel: true, titulo: "EXCLUIR DEFINITIVAMENTE?", mensagem: "ISSO APAGARÁ O EVENTO DA LIXEIRA PARA SEMPRE.", acaoSim: apagarEventoDefinitivo });
              }}><Text style={[styles.textoBotaoSecundario, {color: '#E11D2E'}]}>APAGAR DEFINITIVAMENTE</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, {marginTop: 15}]} onPress={() => { setModalOpcoesLixeiraEvento(false); setEventoLixeiraSel(null); }}><Text style={styles.textoBotaoVoltarBorda}>FECHAR</Text></TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      {modalRecuperarConfirm && (
        <Modal visible={modalRecuperarConfirm} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>CONFIRMAÇÃO</Text>
              <Text style={styles.textoModalMensagem}>VOCÊ QUER MESMO RECUPERAR ESTE LUTADOR?</Text>
              <View style={styles.rowBotoesModal}>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16A34A'}]} onPress={confirmarRecuperacao}><Text style={styles.textoBotaoConfirm}>SIM</Text></TouchableOpacity>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth:1, borderColor:'#2A2A35'}]} onPress={() => setModalRecuperarConfirm(false)}><Text style={styles.textoBotaoConfirm}>NÃO</Text></TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
      {modalApagarDefinitivoConfirm && (
        <Modal visible={modalApagarDefinitivoConfirm} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={[styles.tituloConfirm, {color: '#E11D2E'}]}>EXCLUIR DEFINITIVAMENTE?</Text>
              <Text style={styles.textoModalMensagem}>ISSO APAGARÁ O LUTADOR DA LIXEIRA PARA SEMPRE. O HISTÓRICO DE EVENTOS PASSADOS ONDE ELE LUTOU NÃO SERÁ ALTERADO.</Text>
              <View style={styles.rowBotoesModal}>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#E11D2E'}]} onPress={confirmarApagarDefinitivo}><Text style={styles.textoBotaoConfirm}>APAGAR</Text></TouchableOpacity>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth:1, borderColor:'#2A2A35'}]} onPress={() => { setModalApagarDefinitivoConfirm(false); setLutadorSelecionadoLixeira(null); }}><Text style={styles.textoBotaoConfirm}>CANCELAR</Text></TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
      {modalRetornarLuta && (
        <Modal visible={modalRetornarLuta} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>COMBATE INTERROMPIDO</Text>
              <TouchableOpacity style={[styles.botaoMainNeon, {marginVertical: 10}]} onPress={() => {
                setModalRetornarLuta(false);
                const lutaSegmentada = eventoEmAndamento.lutasAgendadas.find(l => l.idLuta === idLutaAtiva);
                const dados = lutaSegmentada.dadosSalvos;
                setVida1(dados.vida1); setVida2(dados.vida2);
                setTurnos1(dados.turnos1); setTurnos2(dados.turnos2);
                setRoundAtual(dados.roundAtual); setRounds(dados.rounds);
                setVezDeQuem(dados.vezDeQuem);
                setStats(dados.stats || STATS_ZERADOS);
                setPilhaTurnos(dados.pilhaTurnos || []);
                setPilhaDano(dados.pilhaDano || []);
                setRoundScores(dados.roundScores || []);
                vidaAnim1.setValue(dados.vida1);
                vidaAnim2.setValue(dados.vida2);
                setTela("luta");
              }}><Text style={styles.textoBotaoMain}>CONTINUAR DE ONDE PAROU</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoSecundarioBorda, {borderColor: '#E11D2E', marginVertical: 10}]} onPress={() => {
                setModalRetornarLuta(false);
                const targetId = idLutaAtiva;
                resetarEstadosDeCombate();
                setIdLutaAtiva(targetId);
                iniciarLuta();
              }}><Text style={[styles.textoBotaoSecundario, {color: '#E11D2E'}]}>REINICIAR LUTA DO ZERO</Text></TouchableOpacity>
              <TouchableOpacity style={[styles.botaoVoltarCinzaBorda, {marginTop: 15}]} onPress={() => setModalRetornarLuta(false)}><Text style={styles.textoBotaoVoltarBorda}>CANCELAR</Text></TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      {modalAbandonar && (
        <Modal visible={modalAbandonar} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>ABANDONAR COMBATE?</Text>
              <Text style={styles.textoModalMensagem}>O PROGRESSO DOS TURNOS E DA VIDA SERÁ CONSERVADO PARA CONTINUAÇÃO RÁPIDA.</Text>
              <View style={styles.rowBotoesModal}>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#E11D2E'}]} onPress={handleConfirmarAbandono}><Text style={styles.textoBotaoConfirm}>SIM</Text></TouchableOpacity>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth:1, borderColor:'#2A2A35'}]} onPress={()=>setModalAbandonar(false)}><Text style={styles.textoBotaoConfirm}>NÃO</Text></TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
      {modalAlerta.visivel && (
        <Modal visible={modalAlerta.visivel} transparent animationType="fade">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>{modalAlerta.titulo}</Text>
              <Text style={styles.textoModalMensagem}>{modalAlerta.mensagem}</Text>
              <TouchableOpacity style={styles.botaoMainNeon} onPress={() => { setModalAlerta({ ...modalAlerta, visivel: false }); if(modalAlerta.acaoOk) modalAlerta.acaoOk(); }}>
                <Text style={styles.textoBotaoMain}>OK</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      )}
      {modalConfirmarGeral.visivel && (
        <Modal visible={modalConfirmarGeral.visivel} transparent animationType="slide">
          <View style={styles.modalOverlayCentro}>
            <View style={styles.modalConfirmBox}>
              <Text style={styles.tituloConfirm}>{modalConfirmarGeral.titulo}</Text>
              <Text style={styles.textoModalMensagem}>{modalConfirmarGeral.mensagem}</Text>
              <View style={styles.rowBotoesModal}>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#E11D2E'}]} onPress={() => { const acao = modalConfirmarGeral.acaoSim; setModalConfirmarGeral({ ...modalConfirmarGeral, visivel: false }); if(acao) acao(); }}>
                  <Text style={styles.textoBotaoConfirm}>SIM</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.botaoConfirmModal, {backgroundColor: '#16161D', borderWidth:1, borderColor:'#2A2A35'}]} onPress={() => setModalConfirmarGeral({ ...modalConfirmarGeral, visivel: false })}>
                  <Text style={styles.textoBotaoConfirm}>NÃO</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </Modal>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  telaDeFundoAbsoluto: { flex: 1, backgroundColor: "#07070A" },
  faixaTopoVermelha: { height: 3, width: '100%', backgroundColor: '#E11D2E', position: 'absolute', top: 0, left: 0, right: 0, zIndex: 20 },
  container: { flex: 1, backgroundColor: "#07070A", padding: 22, paddingTop: 54, alignItems: 'center' },
  containerCentro: { flex: 1, backgroundColor: "#07070A", justifyContent: "center", padding: 26, alignItems: 'center' },
  containerDashboardLuta: { flex: 1, backgroundColor: "#07070A", padding: 16, paddingTop: 48, alignItems: 'center' },
  header: { width: '100%', alignItems: 'flex-end', position: 'absolute', top: 48, right: 25, zIndex: 10 },
  hitboxMenu: { padding: 8 },
  tresPontos: { color: '#E11D2E', fontSize: 32, fontWeight: '900' },
  globalContentContainer: { alignItems: 'center', width: '100%', paddingBottom: 20 },
  elementoLarguraPadrao: { width: '100%', maxWidth: 480, alignSelf: 'center' },
  titulo: { color: "#F5F5F7", fontSize: 22, fontWeight: "900", textAlign: "center", marginBottom: 25, letterSpacing: 2.5, width: '100%', textShadowColor: 'rgba(225,29,46,0.45)', textShadowOffset: { width: 0, height: 0 }, textShadowRadius: 12 },
  subtituloInformativo: { color: '#8A8A98', textAlign: 'center', marginBottom: 18, fontSize: 11, fontWeight: '700', letterSpacing: 1, width: '100%' },
  nomeLabel: { color: '#A3A3B0', fontSize: 12, fontWeight: '800', letterSpacing: 1.2, marginBottom: 8, width: '100%', maxWidth: 480, textAlign: 'left' },
  botaoMainNeon: { backgroundColor: "#E11D2E", height: 58, borderRadius: 14, alignItems: "center", justifyContent: 'center', shadowColor: '#E11D2E', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.5, shadowRadius: 14, elevation: 8, width: '100%', maxWidth: 480, alignSelf: 'center', borderWidth: 1, borderColor: 'rgba(255,255,255,0.12)' },
  botaoMainAtivoAzul: { backgroundColor: '#1E40AF', borderColor: '#3B82F6' },
  textoBotaoMain: { color: "#FFFFFF", fontSize: 14, fontWeight: "900", letterSpacing: 1.6 },
  botaoSecundarioBorda: { backgroundColor: "#0E0E14", height: 56, borderRadius: 14, borderWidth: 1.5, borderColor: "#E11D2E", alignItems: "center", justifyContent: 'center', width: '100%', maxWidth: 480, alignSelf: 'center' },
  textoBotaoSecundario: { color: "#E11D2E", fontSize: 14, fontWeight: "900", letterSpacing: 1.5 },
  textoBotaoSecundarioBranco: { color: "#F5F5F7", fontSize: 14, fontWeight: "900", letterSpacing: 1.5 },
  botaoListaCard: { backgroundColor: "#101015", paddingVertical: 17, paddingHorizontal: 20, borderRadius: 14, marginVertical: 6, borderWidth: 1, borderColor: '#23232D', width: '100%', maxWidth: 480, alignSelf: 'center', shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.4, shadowRadius: 6, elevation: 3 },
  botaoListaCardSelecionado: { backgroundColor: '#E11D2E', borderColor: '#FF5A68' },
  textoBotaoCardLista: { color: "#C4C4CE", fontSize: 14, textAlign: "center", fontWeight: '800', letterSpacing: 1 },
  botaoVoltarCinzaBorda: { backgroundColor: 'transparent', borderWidth: 1, borderColor: '#2A2A35', height: 52, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginTop: 22, width: '100%', maxWidth: 480, alignSelf: 'center' },
  textoBotaoVoltarBorda: { color: '#8A8A98', fontSize: 13, fontWeight: '800', letterSpacing: 1 },
  inputPremium: { backgroundColor: "#101015", color: "#F5F5F7", height: 54, borderRadius: 12, paddingHorizontal: 16, marginBottom: 15, fontSize: 14, fontWeight: '700', borderWidth: 1, borderColor: '#2A2A35', letterSpacing: 0.5, width: '100%', maxWidth: 480, alignSelf: 'center' },
  rowCategoriasTabs: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', marginBottom: 25, width: '100%', maxWidth: 480, alignSelf: 'center' },
  tabCategoriaBotao: { backgroundColor: "#101015", paddingVertical: 13, paddingHorizontal: 8, borderRadius: 10, flexGrow: 1, minWidth: '30%', marginHorizontal: 3, marginBottom: 6, alignItems: 'center', borderWidth: 1, borderColor: '#23232D' },
  tabCategoriaAtiva: { backgroundColor: '#E11D2E', borderColor: '#FF5A68' },
  textoBotaoAlvo: { color: "#FFFFFF", fontSize: 11, fontWeight: "900", letterSpacing: 0.5 },
  rowGerenciarCard: { flexDirection: "row", backgroundColor: "#101015", marginVertical: 5, borderRadius: 12, alignItems: "center", height: 58, overflow: 'hidden', borderWidth: 1, borderColor: '#23232D' },
  containerControlesDeslocamento: { width: 52, height: '100%', backgroundColor: '#0A0A0E', justifyContent: 'space-evenly', alignItems: 'center', borderRightWidth: 1, borderRightColor: '#23232D' },
  botaoSetaDeslocar: { width: '100%', height: '50%', justifyContent: 'center', alignItems: 'center' },
  textoSeta: { color: '#E11D2E', fontSize: 12, fontWeight: '900' },
  botaoGerenciarNome: { flex: 1, paddingLeft: 18, height: '100%', justifyContent: 'center' },
  textoBotaoCardLutador: { color: '#F5F5F7', fontSize: 14, fontWeight: '800', letterSpacing: 0.5 },
  botaoExcluirLutador: { width: 52, height: '100%', backgroundColor: 'rgba(225,29,46,0.07)', justifyContent: 'center', alignItems: 'center', borderLeftWidth: 1, borderLeftColor: 'rgba(225,29,46,0.15)' },
  textoListaVazia: { color: '#55555F', textAlign: 'center', marginTop: 50, fontWeight: '700', letterSpacing: 1, width: '100%' },
  botaoLixeiraItemCard: { flexDirection: 'row', backgroundColor: '#101015', marginVertical: 6, borderRadius: 12, paddingLeft: 18, alignItems: 'center', height: 60, borderWidth: 1, borderColor: '#23232D', overflow: 'hidden' },
  textoLutadorLixeiraNome: { color: '#F5F5F7', fontSize: 14, fontWeight: '800', letterSpacing: 0.5 },
  textoLutadorLixeiraSub: { color: '#8A8A98', fontSize: 11, fontWeight: '700', marginTop: 2, letterSpacing: 0.5 },
  botaoLixeiraApagarDefinitivo: { width: 54, height: '100%', backgroundColor: '#2A0A0E', justifyContent: 'center', alignItems: 'center', borderLeftWidth: 1, borderLeftColor: '#4A1219' },
  cardEventoCompletoBox: { backgroundColor: '#101015', borderRadius: 16, padding: 16, marginBottom: 18, borderWidth: 1, borderColor: '#23232D', borderTopWidth: 3, borderTopColor: '#E11D2E' },
  headerCardEventoBox: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, borderBottomWidth: 1, borderBottomColor: '#23232D', paddingBottom: 10 },
  nomeEventoTituloBox: { color: '#FFFFFF', fontSize: 16, fontWeight: '900', letterSpacing: 1.5, fontStyle: 'italic' },
  textoExcluirCardAction: { color: '#E11D2E', fontWeight: '900', fontSize: 11, letterSpacing: 1 },
  rowLutaHistBox: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  confrontoTextoCards: { color: '#F5F5F7', fontWeight: '800', fontSize: 14, letterSpacing: 0.5 },
  resultadoContainerBox: { marginTop: 8, backgroundColor: '#07070A', padding: 10, borderRadius: 8, borderWidth: 1, borderColor: '#1A1A22' },
  vencedorLabelBox: { color: '#8A8A98', fontSize: 11, fontWeight: '800', letterSpacing: 0.5 },
  detalheResultadoBox: { color: '#E11D2E', fontSize: 12, marginTop: 3, fontWeight: '800', letterSpacing: 0.5 },
  linhaStatsTxt: { color: '#F5C451', fontSize: 10.5, fontWeight: '800', letterSpacing: 0.8, marginTop: 6 },
  subCardLutaHistorica: { backgroundColor: '#0B0B10', padding: 14, borderRadius: 10, marginTop: 10, borderWidth: 1, borderColor: '#1A1A22', width: '100%' },
  nomeEventoSubCard: { color: '#6B6B78', fontSize: 11, fontWeight: '700', marginTop: 5, letterSpacing: 0.5 },
  metodoDetalheSubCard: { color: '#B4B4C0', fontSize: 12, marginTop: 2, fontWeight: '600' },
  cardLutaAgendadaBox: { flexDirection: 'row', backgroundColor: '#101015', padding: 16, borderRadius: 14, marginVertical: 6, alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderColor: '#23232D', borderLeftWidth: 4, borderLeftColor: '#E11D2E' },
  tagLabelCardLuta: { color: '#E11D2E', fontSize: 10, fontWeight: '900', letterSpacing: 1.2 },
  nomesCardLutaTxt: { color: '#F5F5F7', fontSize: 15, fontWeight: '800', marginTop: 4, letterSpacing: 0.5 },
  botaoRemoverLutaAgendada: { paddingVertical: 7, paddingHorizontal: 12, borderRadius: 8, backgroundColor: 'rgba(225,29,46,0.1)' },
  logoContainerOuter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginVertical: 40, width: '100%' },
  logoMolduraEsquerda: { width: 5, height: 85, backgroundColor: '#E11D2E', marginRight: 15, borderRadius: 2 },
  logoMolduraDireita: { width: 5, height: 85, backgroundColor: '#E11D2E', marginLeft: 15, borderRadius: 2 },
  logoContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  logoUfcQuadrado: { backgroundColor: '#E11D2E', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 6 },
  logoUfcTexto: { color: '#FFF', fontSize: 34, fontWeight: '900', letterSpacing: 2, fontStyle: 'italic' },
  logoDivisorVertical: { width: 2, height: 56, backgroundColor: '#2A2A35', marginHorizontal: 14 },
  logoCiemsContainer: { alignItems: 'flex-start' },
  logoCiemsTexto: { color: '#F5F5F7', fontSize: 28, fontWeight: '900', letterSpacing: 3 },
  logoSubTexto: { color: '#8A8A98', fontSize: 10, fontWeight: '800', letterSpacing: 3, marginTop: 2 },
  cinturaoContainer: { width: 34, height: 18, alignItems: 'center', justifyContent: 'center' },
  cinturaoBase: { width: 34, height: 10, borderRadius: 3 },
  cinturaoCircle: { position: 'absolute', width: 14, height: 14, borderRadius: 7, borderWidth: 1, borderColor: 'rgba(0,0,0,0.35)' },
  iconeMaisContainer: { width: 18, height: 18, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  iconeMaisHorizontal: { position: 'absolute', width: 16, height: 3, backgroundColor: '#F5F5F7', borderRadius: 2 },
  iconeMaisVertical: { position: 'absolute', width: 3, height: 16, backgroundColor: '#F5F5F7', borderRadius: 2 },
  iconeEngrenagemContainer: { width: 20, height: 20, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  iconeEngrenagemCentro: { width: 12, height: 12, borderRadius: 6, borderWidth: 3, borderColor: '#F5F5F7', backgroundColor: '#0E0E14' },
  iconeEngrenagemDente: { position: 'absolute', width: 4, height: 20, backgroundColor: '#F5F5F7', borderRadius: 2, zIndex: -1 },
  iconeLixeiraContainer: { width: 16, height: 18, alignItems: 'center' },
  iconeLixeiraTampa: { width: 16, height: 2, borderRadius: 1, marginTop: 2 },
  iconeLixeiraAlca: { position: 'absolute', top: 0, width: 6, height: 3, borderWidth: 1.5, borderBottomWidth: 0, borderTopLeftRadius: 2, borderTopRightRadius: 2 },
  iconeLixeiraCorpo: { width: 12, height: 12, borderWidth: 1.5, borderTopWidth: 0, borderBottomLeftRadius: 3, borderBottomRightRadius: 3, flexDirection: 'row', justifyContent: 'space-evenly', alignItems: 'center', marginTop: 1 },
  iconeLixeiraLinha: { width: 1.5, height: 6, borderRadius: 1 },
  statBox: { flex: 1, alignItems: 'center', marginHorizontal: 4 },
  statRotulo: { color: '#8A8A98', fontSize: 10, fontWeight: '800', letterSpacing: 1, marginBottom: 6 },
  statLinha: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  statBtn: { width: 34, height: 34, borderRadius: 10, borderWidth: 1, borderColor: '#2A2A35', backgroundColor: '#0B0B10', alignItems: 'center', justifyContent: 'center' },
  statBtnTxt: { color: '#8A8A98', fontSize: 18, fontWeight: '900' },
  statValor: { fontSize: 20, fontWeight: '900', minWidth: 34, textAlign: 'center' },
  rowBotaoComIcone: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  rowBotaoComIconeEsquerda: { flexDirection: 'row', alignItems: 'center' },
  rowTituloComIcone: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  divisorLine: { height: 1, backgroundColor: '#23232D', marginVertical: 18 },
  cardFormularioEdicao: { backgroundColor: '#101015', borderRadius: 16, padding: 18, borderWidth: 1, borderColor: '#23232D', borderTopWidth: 3, borderTopColor: '#E11D2E' },
  cardConfiguracaoCombate: { backgroundColor: '#101015', borderRadius: 16, padding: 16, marginTop: 16, borderWidth: 1, borderColor: '#23232D' },
  tituloSecundarioConfig: { color: '#A3A3B0', fontSize: 12, fontWeight: '900', letterSpacing: 1.5, textAlign: 'center', marginBottom: 12 },
  rowBotoesCinturao: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 14 },
  botaoCinturaoOpcao: { flex: 1, height: 46, marginHorizontal: 4, borderRadius: 10, borderWidth: 1, borderColor: '#2A2A35', backgroundColor: '#0B0B10', alignItems: 'center', justifyContent: 'center' },
  textoBotaoCint: { color: '#C4C4CE', fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  tagTreinoBadge: { backgroundColor: 'rgba(234,179,8,0.12)', borderWidth: 1, borderColor: '#EAB308', paddingVertical: 4, paddingHorizontal: 12, borderRadius: 8, marginBottom: 8 },
  tagTreinoTxt: { color: '#EAB308', fontSize: 10, fontWeight: '900', letterSpacing: 1.2 },
  headerLutaTransmissao: { color: '#8A8A98', fontSize: 11, fontWeight: '800', letterSpacing: 1.2, textAlign: 'center', marginBottom: 8 },
  roundBadge: { backgroundColor: '#E11D2E', paddingVertical: 6, paddingHorizontal: 18, borderRadius: 20, marginBottom: 14 },
  roundContadorGlobal: { color: '#FFF', fontSize: 13, fontWeight: '900', letterSpacing: 2 },
  painelLutadorStatus: { backgroundColor: '#101015', borderRadius: 14, padding: 14, borderWidth: 1, borderColor: '#23232D', borderLeftWidth: 4 },
  rowStatusLutadorHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  rowNomeEHp: { flex: 1 },
  nomeLutadorDashboard: { color: '#F5F5F7', fontSize: 16, fontWeight: '900', letterSpacing: 0.5 },
  hpNumericoTexto: { color: '#8A8A98', fontSize: 12, fontWeight: '800', marginTop: 2 },
  turnoLabelContador: { color: '#C4C4CE', fontSize: 12, fontWeight: '800', letterSpacing: 1 },
  containerBarraFundoGauge: { height: 14, backgroundColor: '#07070A', borderRadius: 7, overflow: 'hidden', borderWidth: 1, borderColor: '#23232D', marginBottom: 12 },
  barraHPGauge: { height: '100%', borderRadius: 7 },
  rowStats: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  botaoTurnoAcao: { backgroundColor: '#1A1A22', height: 46, borderRadius: 10, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#2A2A35' },
  textoBotaoTurno: { color: '#F5F5F7', fontSize: 12, fontWeight: '900', letterSpacing: 1 },
  rowDesfazer: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 14 },
  botaoDesfazer: { flex: 1, height: 42, marginHorizontal: 4, borderRadius: 10, borderWidth: 1, borderColor: '#2A2A35', backgroundColor: '#0B0B10', alignItems: 'center', justifyContent: 'center' },
  textoDesfazer: { color: '#C4C4CE', fontSize: 11, fontWeight: '900', letterSpacing: 1 },
  painelFimRoundAlerta: { backgroundColor: '#1A0A0D', borderRadius: 14, padding: 16, marginTop: 18, borderWidth: 1, borderColor: '#E11D2E', alignItems: 'center' },
  textoFimRoundAlerta: { color: '#E11D2E', fontSize: 18, fontWeight: '900', letterSpacing: 2, marginBottom: 14 },
  rowTaticoAlvo: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  botaoAlvoTatico: { flex: 1, backgroundColor: '#101015', paddingVertical: 14, marginHorizontal: 4, borderRadius: 10, alignItems: 'center', borderWidth: 1, borderColor: '#23232D' },
  botaoAlvoTaticoAtivo: { backgroundColor: '#E11D2E', borderColor: '#FF5A68' },
  rowMetodosAtaque: { flexDirection: 'row', justifyContent: 'space-between' },
  botaoMetodoFim: { flex: 1, height: 48, marginHorizontal: 4, borderRadius: 10, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: 'transparent' },
  metodoKo: { backgroundColor: '#7F1D1D' },
  metodoTko: { backgroundColor: '#9A3412' },
  metodoSub: { backgroundColor: '#1E3A8A' },
  metodoSelecionadoBorda: { borderColor: '#FFFFFF' },
  textoMetodoCardFim: { color: '#FFF', fontSize: 14, fontWeight: '900', letterSpacing: 1.5 },
  rowPlacarJuizesContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  colunaPlacarLutador: { flex: 1, alignItems: 'center' },
  nomeLutadorPlacarJuizes: { color: '#F5F5F7', fontSize: 13, fontWeight: '800', letterSpacing: 0.5, marginBottom: 10, textAlign: 'center' },
  textoVersusJuizes: { color: '#E11D2E', fontSize: 20, fontWeight: '900', marginHorizontal: 10 },
  inputPontosCard: { backgroundColor: '#101015', color: '#F5F5F7', width: 90, height: 70, borderRadius: 12, borderWidth: 1, borderColor: '#2A2A35', fontSize: 30, fontWeight: '900', textAlign: 'center' },
  cardResultado: { backgroundColor: '#101015', borderRadius: 18, padding: 26, alignItems: 'center', borderWidth: 1, borderColor: '#23232D', borderTopWidth: 3, borderTopColor: '#E11D2E', marginBottom: 10 },
  vencedorNomePlacard: { color: '#FFFFFF', fontSize: 26, fontWeight: '900', letterSpacing: 1.5, textAlign: 'center', marginBottom: 6 },
  cartelTxtDestaque: { color: '#F5C451', fontSize: 20, fontWeight: '900', letterSpacing: 2, textAlign: 'center', marginBottom: 14 },
  metodoTxtDestaque: { color: '#E11D2E', fontSize: 22, fontWeight: '900', letterSpacing: 2, marginTop: 4 },
  subMetodoTxtDetalhe: { color: '#8A8A98', fontSize: 12, fontWeight: '800', letterSpacing: 1, marginTop: 6 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'flex-end', paddingTop: 90, paddingRight: 20 },
  modalMenu: { backgroundColor: '#101015', borderRadius: 14, borderWidth: 1, borderColor: '#23232D', minWidth: 240, overflow: 'hidden' },
  menuItem: { paddingVertical: 16, paddingHorizontal: 20, borderBottomWidth: 1, borderBottomColor: '#23232D' },
  menuText: { color: '#F5F5F7', fontSize: 13, fontWeight: '800', letterSpacing: 1 },
  modalOverlayCentro: { flex: 1, backgroundColor: 'rgba(0,0,0,0.78)', justifyContent: 'center', alignItems: 'center', padding: 24 },
  modalConfirmBox: { width: '100%', maxWidth: 420, backgroundColor: '#101015', borderRadius: 18, padding: 22, borderWidth: 1, borderColor: '#2A2A35', borderTopWidth: 3, borderTopColor: '#E11D2E' },
  tituloConfirm: { color: '#F5F5F7', fontSize: 17, fontWeight: '900', letterSpacing: 1.5, textAlign: 'center', marginBottom: 12 },
  textoModalMensagem: { color: '#A3A3B0', fontSize: 13, fontWeight: '700', lineHeight: 20, textAlign: 'center', marginBottom: 20, letterSpacing: 0.5 },
  rowBotoesModal: { flexDirection: 'row', justifyContent: 'space-between' },
  botaoConfirmModal: { flex: 1, height: 48, marginHorizontal: 5, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  textoBotaoConfirm: { color: '#FFF', fontSize: 13, fontWeight: '900', letterSpacing: 1.2 },
});
